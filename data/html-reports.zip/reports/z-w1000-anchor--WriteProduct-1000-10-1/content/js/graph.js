/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 20.0, "minX": 0.0, "maxY": 453.0, "series": [{"data": [[0.0, 20.0], [0.1, 20.0], [0.2, 21.0], [0.3, 21.0], [0.4, 21.0], [0.5, 21.0], [0.6, 21.0], [0.7, 22.0], [0.8, 22.0], [0.9, 22.0], [1.0, 22.0], [1.1, 22.0], [1.2, 22.0], [1.3, 22.0], [1.4, 22.0], [1.5, 22.0], [1.6, 22.0], [1.7, 22.0], [1.8, 22.0], [1.9, 22.0], [2.0, 22.0], [2.1, 22.0], [2.2, 22.0], [2.3, 22.0], [2.4, 22.0], [2.5, 22.0], [2.6, 22.0], [2.7, 22.0], [2.8, 22.0], [2.9, 22.0], [3.0, 23.0], [3.1, 23.0], [3.2, 23.0], [3.3, 23.0], [3.4, 23.0], [3.5, 23.0], [3.6, 23.0], [3.7, 23.0], [3.8, 23.0], [3.9, 23.0], [4.0, 23.0], [4.1, 23.0], [4.2, 23.0], [4.3, 23.0], [4.4, 23.0], [4.5, 23.0], [4.6, 23.0], [4.7, 23.0], [4.8, 23.0], [4.9, 23.0], [5.0, 23.0], [5.1, 23.0], [5.2, 23.0], [5.3, 23.0], [5.4, 23.0], [5.5, 23.0], [5.6, 23.0], [5.7, 23.0], [5.8, 23.0], [5.9, 23.0], [6.0, 23.0], [6.1, 23.0], [6.2, 23.0], [6.3, 23.0], [6.4, 23.0], [6.5, 23.0], [6.6, 23.0], [6.7, 23.0], [6.8, 23.0], [6.9, 23.0], [7.0, 23.0], [7.1, 23.0], [7.2, 23.0], [7.3, 23.0], [7.4, 23.0], [7.5, 23.0], [7.6, 23.0], [7.7, 23.0], [7.8, 23.0], [7.9, 23.0], [8.0, 23.0], [8.1, 23.0], [8.2, 23.0], [8.3, 24.0], [8.4, 24.0], [8.5, 24.0], [8.6, 24.0], [8.7, 24.0], [8.8, 24.0], [8.9, 24.0], [9.0, 24.0], [9.1, 24.0], [9.2, 24.0], [9.3, 24.0], [9.4, 24.0], [9.5, 24.0], [9.6, 24.0], [9.7, 24.0], [9.8, 24.0], [9.9, 24.0], [10.0, 24.0], [10.1, 24.0], [10.2, 24.0], [10.3, 24.0], [10.4, 24.0], [10.5, 24.0], [10.6, 24.0], [10.7, 24.0], [10.8, 24.0], [10.9, 24.0], [11.0, 24.0], [11.1, 24.0], [11.2, 25.0], [11.3, 25.0], [11.4, 25.0], [11.5, 25.0], [11.6, 25.0], [11.7, 25.0], [11.8, 25.0], [11.9, 25.0], [12.0, 25.0], [12.1, 25.0], [12.2, 25.0], [12.3, 25.0], [12.4, 25.0], [12.5, 25.0], [12.6, 25.0], [12.7, 25.0], [12.8, 25.0], [12.9, 25.0], [13.0, 25.0], [13.1, 25.0], [13.2, 25.0], [13.3, 25.0], [13.4, 25.0], [13.5, 25.0], [13.6, 25.0], [13.7, 25.0], [13.8, 25.0], [13.9, 25.0], [14.0, 25.0], [14.1, 25.0], [14.2, 25.0], [14.3, 25.0], [14.4, 25.0], [14.5, 25.0], [14.6, 25.0], [14.7, 25.0], [14.8, 25.0], [14.9, 25.0], [15.0, 25.0], [15.1, 25.0], [15.2, 25.0], [15.3, 25.0], [15.4, 25.0], [15.5, 26.0], [15.6, 26.0], [15.7, 26.0], [15.8, 26.0], [15.9, 26.0], [16.0, 26.0], [16.1, 26.0], [16.2, 26.0], [16.3, 26.0], [16.4, 26.0], [16.5, 26.0], [16.6, 26.0], [16.7, 26.0], [16.8, 26.0], [16.9, 26.0], [17.0, 26.0], [17.1, 26.0], [17.2, 26.0], [17.3, 26.0], [17.4, 26.0], [17.5, 26.0], [17.6, 26.0], [17.7, 26.0], [17.8, 26.0], [17.9, 26.0], [18.0, 26.0], [18.1, 26.0], [18.2, 26.0], [18.3, 26.0], [18.4, 26.0], [18.5, 26.0], [18.6, 26.0], [18.7, 26.0], [18.8, 26.0], [18.9, 26.0], [19.0, 26.0], [19.1, 26.0], [19.2, 26.0], [19.3, 26.0], [19.4, 26.0], [19.5, 26.0], [19.6, 26.0], [19.7, 26.0], [19.8, 26.0], [19.9, 26.0], [20.0, 26.0], [20.1, 26.0], [20.2, 26.0], [20.3, 26.0], [20.4, 26.0], [20.5, 26.0], [20.6, 26.0], [20.7, 26.0], [20.8, 26.0], [20.9, 26.0], [21.0, 26.0], [21.1, 26.0], [21.2, 26.0], [21.3, 26.0], [21.4, 26.0], [21.5, 26.0], [21.6, 26.0], [21.7, 26.0], [21.8, 26.0], [21.9, 26.0], [22.0, 27.0], [22.1, 27.0], [22.2, 27.0], [22.3, 27.0], [22.4, 27.0], [22.5, 27.0], [22.6, 27.0], [22.7, 27.0], [22.8, 27.0], [22.9, 27.0], [23.0, 27.0], [23.1, 27.0], [23.2, 27.0], [23.3, 27.0], [23.4, 27.0], [23.5, 27.0], [23.6, 27.0], [23.7, 27.0], [23.8, 27.0], [23.9, 27.0], [24.0, 27.0], [24.1, 27.0], [24.2, 27.0], [24.3, 27.0], [24.4, 27.0], [24.5, 27.0], [24.6, 27.0], [24.7, 27.0], [24.8, 27.0], [24.9, 27.0], [25.0, 27.0], [25.1, 27.0], [25.2, 27.0], [25.3, 27.0], [25.4, 27.0], [25.5, 27.0], [25.6, 27.0], [25.7, 27.0], [25.8, 27.0], [25.9, 27.0], [26.0, 27.0], [26.1, 27.0], [26.2, 27.0], [26.3, 27.0], [26.4, 27.0], [26.5, 27.0], [26.6, 27.0], [26.7, 28.0], [26.8, 28.0], [26.9, 28.0], [27.0, 28.0], [27.1, 28.0], [27.2, 28.0], [27.3, 28.0], [27.4, 28.0], [27.5, 28.0], [27.6, 28.0], [27.7, 28.0], [27.8, 28.0], [27.9, 28.0], [28.0, 28.0], [28.1, 28.0], [28.2, 28.0], [28.3, 28.0], [28.4, 28.0], [28.5, 28.0], [28.6, 29.0], [28.7, 29.0], [28.8, 29.0], [28.9, 29.0], [29.0, 29.0], [29.1, 29.0], [29.2, 29.0], [29.3, 29.0], [29.4, 29.0], [29.5, 29.0], [29.6, 29.0], [29.7, 29.0], [29.8, 29.0], [29.9, 30.0], [30.0, 30.0], [30.1, 30.0], [30.2, 30.0], [30.3, 30.0], [30.4, 30.0], [30.5, 30.0], [30.6, 30.0], [30.7, 30.0], [30.8, 30.0], [30.9, 30.0], [31.0, 30.0], [31.1, 30.0], [31.2, 30.0], [31.3, 30.0], [31.4, 31.0], [31.5, 31.0], [31.6, 31.0], [31.7, 31.0], [31.8, 31.0], [31.9, 31.0], [32.0, 31.0], [32.1, 31.0], [32.2, 31.0], [32.3, 31.0], [32.4, 31.0], [32.5, 31.0], [32.6, 31.0], [32.7, 31.0], [32.8, 31.0], [32.9, 31.0], [33.0, 31.0], [33.1, 31.0], [33.2, 31.0], [33.3, 31.0], [33.4, 31.0], [33.5, 31.0], [33.6, 31.0], [33.7, 31.0], [33.8, 31.0], [33.9, 31.0], [34.0, 31.0], [34.1, 31.0], [34.2, 31.0], [34.3, 31.0], [34.4, 31.0], [34.5, 31.0], [34.6, 31.0], [34.7, 31.0], [34.8, 31.0], [34.9, 31.0], [35.0, 31.0], [35.1, 31.0], [35.2, 32.0], [35.3, 32.0], [35.4, 32.0], [35.5, 32.0], [35.6, 32.0], [35.7, 32.0], [35.8, 32.0], [35.9, 32.0], [36.0, 32.0], [36.1, 32.0], [36.2, 32.0], [36.3, 32.0], [36.4, 32.0], [36.5, 32.0], [36.6, 32.0], [36.7, 32.0], [36.8, 32.0], [36.9, 32.0], [37.0, 32.0], [37.1, 32.0], [37.2, 32.0], [37.3, 32.0], [37.4, 32.0], [37.5, 32.0], [37.6, 32.0], [37.7, 32.0], [37.8, 32.0], [37.9, 32.0], [38.0, 32.0], [38.1, 32.0], [38.2, 32.0], [38.3, 32.0], [38.4, 32.0], [38.5, 32.0], [38.6, 32.0], [38.7, 32.0], [38.8, 32.0], [38.9, 32.0], [39.0, 32.0], [39.1, 33.0], [39.2, 33.0], [39.3, 33.0], [39.4, 33.0], [39.5, 33.0], [39.6, 33.0], [39.7, 33.0], [39.8, 33.0], [39.9, 33.0], [40.0, 33.0], [40.1, 33.0], [40.2, 33.0], [40.3, 33.0], [40.4, 33.0], [40.5, 33.0], [40.6, 33.0], [40.7, 33.0], [40.8, 33.0], [40.9, 33.0], [41.0, 33.0], [41.1, 33.0], [41.2, 33.0], [41.3, 33.0], [41.4, 33.0], [41.5, 33.0], [41.6, 33.0], [41.7, 33.0], [41.8, 33.0], [41.9, 33.0], [42.0, 33.0], [42.1, 33.0], [42.2, 33.0], [42.3, 33.0], [42.4, 33.0], [42.5, 33.0], [42.6, 33.0], [42.7, 33.0], [42.8, 33.0], [42.9, 34.0], [43.0, 34.0], [43.1, 34.0], [43.2, 34.0], [43.3, 34.0], [43.4, 34.0], [43.5, 34.0], [43.6, 34.0], [43.7, 34.0], [43.8, 34.0], [43.9, 34.0], [44.0, 34.0], [44.1, 34.0], [44.2, 34.0], [44.3, 34.0], [44.4, 34.0], [44.5, 34.0], [44.6, 34.0], [44.7, 34.0], [44.8, 34.0], [44.9, 34.0], [45.0, 34.0], [45.1, 34.0], [45.2, 34.0], [45.3, 34.0], [45.4, 34.0], [45.5, 34.0], [45.6, 34.0], [45.7, 34.0], [45.8, 34.0], [45.9, 34.0], [46.0, 34.0], [46.1, 34.0], [46.2, 35.0], [46.3, 35.0], [46.4, 35.0], [46.5, 35.0], [46.6, 35.0], [46.7, 35.0], [46.8, 35.0], [46.9, 35.0], [47.0, 35.0], [47.1, 35.0], [47.2, 35.0], [47.3, 35.0], [47.4, 35.0], [47.5, 35.0], [47.6, 35.0], [47.7, 35.0], [47.8, 35.0], [47.9, 35.0], [48.0, 35.0], [48.1, 35.0], [48.2, 35.0], [48.3, 35.0], [48.4, 35.0], [48.5, 35.0], [48.6, 35.0], [48.7, 35.0], [48.8, 35.0], [48.9, 35.0], [49.0, 35.0], [49.1, 35.0], [49.2, 35.0], [49.3, 35.0], [49.4, 35.0], [49.5, 35.0], [49.6, 36.0], [49.7, 36.0], [49.8, 36.0], [49.9, 36.0], [50.0, 36.0], [50.1, 36.0], [50.2, 36.0], [50.3, 36.0], [50.4, 36.0], [50.5, 36.0], [50.6, 36.0], [50.7, 36.0], [50.8, 36.0], [50.9, 36.0], [51.0, 36.0], [51.1, 36.0], [51.2, 36.0], [51.3, 36.0], [51.4, 36.0], [51.5, 36.0], [51.6, 36.0], [51.7, 36.0], [51.8, 36.0], [51.9, 36.0], [52.0, 36.0], [52.1, 36.0], [52.2, 36.0], [52.3, 36.0], [52.4, 36.0], [52.5, 36.0], [52.6, 36.0], [52.7, 36.0], [52.8, 36.0], [52.9, 36.0], [53.0, 36.0], [53.1, 36.0], [53.2, 36.0], [53.3, 36.0], [53.4, 36.0], [53.5, 36.0], [53.6, 36.0], [53.7, 37.0], [53.8, 37.0], [53.9, 37.0], [54.0, 37.0], [54.1, 37.0], [54.2, 37.0], [54.3, 37.0], [54.4, 37.0], [54.5, 37.0], [54.6, 37.0], [54.7, 37.0], [54.8, 37.0], [54.9, 37.0], [55.0, 37.0], [55.1, 37.0], [55.2, 37.0], [55.3, 37.0], [55.4, 37.0], [55.5, 37.0], [55.6, 37.0], [55.7, 37.0], [55.8, 37.0], [55.9, 37.0], [56.0, 37.0], [56.1, 37.0], [56.2, 37.0], [56.3, 37.0], [56.4, 37.0], [56.5, 37.0], [56.6, 37.0], [56.7, 38.0], [56.8, 38.0], [56.9, 38.0], [57.0, 38.0], [57.1, 38.0], [57.2, 38.0], [57.3, 38.0], [57.4, 38.0], [57.5, 38.0], [57.6, 38.0], [57.7, 38.0], [57.8, 38.0], [57.9, 38.0], [58.0, 38.0], [58.1, 38.0], [58.2, 38.0], [58.3, 39.0], [58.4, 39.0], [58.5, 39.0], [58.6, 39.0], [58.7, 39.0], [58.8, 39.0], [58.9, 39.0], [59.0, 39.0], [59.1, 39.0], [59.2, 39.0], [59.3, 40.0], [59.4, 40.0], [59.5, 40.0], [59.6, 40.0], [59.7, 40.0], [59.8, 40.0], [59.9, 40.0], [60.0, 40.0], [60.1, 40.0], [60.2, 40.0], [60.3, 40.0], [60.4, 41.0], [60.5, 41.0], [60.6, 41.0], [60.7, 41.0], [60.8, 41.0], [60.9, 41.0], [61.0, 41.0], [61.1, 41.0], [61.2, 41.0], [61.3, 41.0], [61.4, 41.0], [61.5, 42.0], [61.6, 42.0], [61.7, 42.0], [61.8, 42.0], [61.9, 42.0], [62.0, 42.0], [62.1, 42.0], [62.2, 42.0], [62.3, 42.0], [62.4, 42.0], [62.5, 42.0], [62.6, 42.0], [62.7, 43.0], [62.8, 43.0], [62.9, 43.0], [63.0, 43.0], [63.1, 43.0], [63.2, 43.0], [63.3, 43.0], [63.4, 43.0], [63.5, 43.0], [63.6, 44.0], [63.7, 44.0], [63.8, 44.0], [63.9, 44.0], [64.0, 44.0], [64.1, 44.0], [64.2, 44.0], [64.3, 44.0], [64.4, 44.0], [64.5, 45.0], [64.6, 45.0], [64.7, 45.0], [64.8, 45.0], [64.9, 45.0], [65.0, 45.0], [65.1, 45.0], [65.2, 45.0], [65.3, 46.0], [65.4, 46.0], [65.5, 46.0], [65.6, 46.0], [65.7, 46.0], [65.8, 46.0], [65.9, 46.0], [66.0, 46.0], [66.1, 46.0], [66.2, 46.0], [66.3, 46.0], [66.4, 47.0], [66.5, 47.0], [66.6, 47.0], [66.7, 47.0], [66.8, 47.0], [66.9, 47.0], [67.0, 47.0], [67.1, 47.0], [67.2, 47.0], [67.3, 47.0], [67.4, 48.0], [67.5, 48.0], [67.6, 48.0], [67.7, 48.0], [67.8, 48.0], [67.9, 48.0], [68.0, 49.0], [68.1, 49.0], [68.2, 49.0], [68.3, 49.0], [68.4, 49.0], [68.5, 49.0], [68.6, 50.0], [68.7, 50.0], [68.8, 50.0], [68.9, 50.0], [69.0, 50.0], [69.1, 51.0], [69.2, 51.0], [69.3, 51.0], [69.4, 51.0], [69.5, 52.0], [69.6, 52.0], [69.7, 52.0], [69.8, 53.0], [69.9, 53.0], [70.0, 53.0], [70.1, 53.0], [70.2, 53.0], [70.3, 53.0], [70.4, 54.0], [70.5, 54.0], [70.6, 54.0], [70.7, 54.0], [70.8, 54.0], [70.9, 54.0], [71.0, 55.0], [71.1, 56.0], [71.2, 56.0], [71.3, 57.0], [71.4, 58.0], [71.5, 59.0], [71.6, 60.0], [71.7, 60.0], [71.8, 60.0], [71.9, 61.0], [72.0, 61.0], [72.1, 61.0], [72.2, 62.0], [72.3, 62.0], [72.4, 63.0], [72.5, 63.0], [72.6, 64.0], [72.7, 64.0], [72.8, 64.0], [72.9, 64.0], [73.0, 64.0], [73.1, 64.0], [73.2, 65.0], [73.3, 66.0], [73.4, 66.0], [73.5, 66.0], [73.6, 67.0], [73.7, 67.0], [73.8, 67.0], [73.9, 67.0], [74.0, 67.0], [74.1, 68.0], [74.2, 68.0], [74.3, 68.0], [74.4, 68.0], [74.5, 68.0], [74.6, 69.0], [74.7, 69.0], [74.8, 69.0], [74.9, 70.0], [75.0, 72.0], [75.1, 73.0], [75.2, 73.0], [75.3, 74.0], [75.4, 74.0], [75.5, 76.0], [75.6, 76.0], [75.7, 76.0], [75.8, 77.0], [75.9, 77.0], [76.0, 77.0], [76.1, 77.0], [76.2, 78.0], [76.3, 78.0], [76.4, 78.0], [76.5, 78.0], [76.6, 79.0], [76.7, 79.0], [76.8, 80.0], [76.9, 80.0], [77.0, 80.0], [77.1, 80.0], [77.2, 82.0], [77.3, 82.0], [77.4, 82.0], [77.5, 83.0], [77.6, 83.0], [77.7, 83.0], [77.8, 84.0], [77.9, 85.0], [78.0, 86.0], [78.1, 87.0], [78.2, 87.0], [78.3, 87.0], [78.4, 88.0], [78.5, 89.0], [78.6, 89.0], [78.7, 89.0], [78.8, 89.0], [78.9, 89.0], [79.0, 91.0], [79.1, 92.0], [79.2, 92.0], [79.3, 93.0], [79.4, 93.0], [79.5, 94.0], [79.6, 96.0], [79.7, 97.0], [79.8, 97.0], [79.9, 97.0], [80.0, 97.0], [80.1, 97.0], [80.2, 98.0], [80.3, 98.0], [80.4, 98.0], [80.5, 99.0], [80.6, 100.0], [80.7, 101.0], [80.8, 101.0], [80.9, 102.0], [81.0, 102.0], [81.1, 103.0], [81.2, 103.0], [81.3, 103.0], [81.4, 104.0], [81.5, 104.0], [81.6, 105.0], [81.7, 106.0], [81.8, 108.0], [81.9, 110.0], [82.0, 110.0], [82.1, 110.0], [82.2, 111.0], [82.3, 111.0], [82.4, 112.0], [82.5, 113.0], [82.6, 113.0], [82.7, 114.0], [82.8, 116.0], [82.9, 116.0], [83.0, 118.0], [83.1, 118.0], [83.2, 120.0], [83.3, 120.0], [83.4, 121.0], [83.5, 124.0], [83.6, 124.0], [83.7, 126.0], [83.8, 126.0], [83.9, 126.0], [84.0, 127.0], [84.1, 127.0], [84.2, 127.0], [84.3, 129.0], [84.4, 130.0], [84.5, 130.0], [84.6, 132.0], [84.7, 132.0], [84.8, 132.0], [84.9, 133.0], [85.0, 133.0], [85.1, 133.0], [85.2, 135.0], [85.3, 135.0], [85.4, 137.0], [85.5, 138.0], [85.6, 139.0], [85.7, 140.0], [85.8, 142.0], [85.9, 143.0], [86.0, 144.0], [86.1, 145.0], [86.2, 145.0], [86.3, 146.0], [86.4, 146.0], [86.5, 147.0], [86.6, 148.0], [86.7, 151.0], [86.8, 151.0], [86.9, 152.0], [87.0, 153.0], [87.1, 153.0], [87.2, 154.0], [87.3, 154.0], [87.4, 154.0], [87.5, 155.0], [87.6, 156.0], [87.7, 157.0], [87.8, 159.0], [87.9, 161.0], [88.0, 161.0], [88.1, 162.0], [88.2, 162.0], [88.3, 165.0], [88.4, 169.0], [88.5, 169.0], [88.6, 170.0], [88.7, 172.0], [88.8, 174.0], [88.9, 175.0], [89.0, 179.0], [89.1, 179.0], [89.2, 179.0], [89.3, 181.0], [89.4, 183.0], [89.5, 184.0], [89.6, 184.0], [89.7, 185.0], [89.8, 186.0], [89.9, 187.0], [90.0, 187.0], [90.1, 190.0], [90.2, 190.0], [90.3, 191.0], [90.4, 192.0], [90.5, 192.0], [90.6, 192.0], [90.7, 192.0], [90.8, 193.0], [90.9, 194.0], [91.0, 195.0], [91.1, 195.0], [91.2, 197.0], [91.3, 198.0], [91.4, 199.0], [91.5, 202.0], [91.6, 204.0], [91.7, 204.0], [91.8, 206.0], [91.9, 206.0], [92.0, 207.0], [92.1, 208.0], [92.2, 208.0], [92.3, 209.0], [92.4, 210.0], [92.5, 212.0], [92.6, 212.0], [92.7, 213.0], [92.8, 214.0], [92.9, 215.0], [93.0, 216.0], [93.1, 216.0], [93.2, 216.0], [93.3, 217.0], [93.4, 217.0], [93.5, 218.0], [93.6, 222.0], [93.7, 226.0], [93.8, 226.0], [93.9, 227.0], [94.0, 231.0], [94.1, 232.0], [94.2, 232.0], [94.3, 232.0], [94.4, 233.0], [94.5, 236.0], [94.6, 238.0], [94.7, 241.0], [94.8, 244.0], [94.9, 245.0], [95.0, 246.0], [95.1, 247.0], [95.2, 248.0], [95.3, 248.0], [95.4, 250.0], [95.5, 252.0], [95.6, 252.0], [95.7, 252.0], [95.8, 252.0], [95.9, 253.0], [96.0, 256.0], [96.1, 257.0], [96.2, 259.0], [96.3, 262.0], [96.4, 264.0], [96.5, 264.0], [96.6, 268.0], [96.7, 268.0], [96.8, 268.0], [96.9, 270.0], [97.0, 278.0], [97.1, 279.0], [97.2, 281.0], [97.3, 283.0], [97.4, 287.0], [97.5, 290.0], [97.6, 293.0], [97.7, 297.0], [97.8, 297.0], [97.9, 299.0], [98.0, 300.0], [98.1, 302.0], [98.2, 306.0], [98.3, 306.0], [98.4, 322.0], [98.5, 325.0], [98.6, 332.0], [98.7, 334.0], [98.8, 337.0], [98.9, 375.0], [99.0, 408.0], [99.1, 409.0], [99.2, 409.0], [99.3, 411.0], [99.4, 423.0], [99.5, 439.0], [99.6, 443.0], [99.7, 444.0], [99.8, 451.0], [99.9, 453.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 10.0, "minX": 0.0, "maxY": 806.0, "series": [{"data": [[0.0, 806.0], [300.0, 10.0], [200.0, 65.0], [400.0, 10.0], [100.0, 109.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 400.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 1000.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 1000.0, "series": [{"data": [[0.0, 1000.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 4.9E-324, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 3.45631067961165, "minX": 1.79273428E12, "maxY": 35.23529411764706, "series": [{"data": [[1.792734284E12, 5.990740740740739], [1.792734283E12, 8.692307692307692], [1.792734285E12, 3.45631067961165], [1.792734286E12, 4.585858585858586], [1.792734288E12, 4.0], [1.792734287E12, 3.574257425742575], [1.792734289E12, 3.5300000000000002], [1.79273428E12, 35.23529411764706], [1.79273429E12, 4.113636363636363], [1.792734281E12, 19.704347826086956], [1.792734282E12, 5.028301886792452]], "isOverall": false, "label": "Thread Group", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.79273429E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 20.0, "minX": 1.0, "maxY": 451.0, "series": [{"data": [[32.0, 345.6666666666667], [2.0, 22.69230769230769], [35.0, 451.0], [34.0, 448.5], [37.0, 318.4], [36.0, 308.6666666666667], [39.0, 292.8], [38.0, 268.0], [41.0, 373.0], [40.0, 302.0], [43.0, 411.0], [42.0, 349.0], [3.0, 26.036496350364956], [4.0, 34.6324503311258], [5.0, 42.902912621359235], [6.0, 54.47222222222222], [7.0, 60.0], [8.0, 81.61111111111111], [9.0, 89.00000000000001], [10.0, 93.55555555555556], [11.0, 109.53333333333332], [12.0, 110.00000000000001], [13.0, 126.12500000000001], [14.0, 130.11764705882354], [15.0, 139.0], [16.0, 141.0], [1.0, 20.0], [17.0, 163.0], [18.0, 177.0], [19.0, 178.14285714285714], [20.0, 195.90909090909093], [21.0, 216.375], [22.0, 195.75], [23.0, 221.44444444444443], [24.0, 230.75], [25.0, 266.375], [26.0, 264.0], [27.0, 249.57142857142856], [28.0, 242.85714285714283], [29.0, 268.0], [31.0, 353.5]], "isOverall": false, "label": "HTTP Request", "isController": false}, {"data": [[7.5359999999999925, 69.35600000000018]], "isOverall": false, "label": "HTTP Request-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 43.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 12900.0, "minX": 1.79273428E12, "maxY": 51968.0, "series": [{"data": [[1.792734284E12, 48781.0], [1.792734283E12, 41125.0], [1.792734285E12, 46541.0], [1.792734286E12, 44763.0], [1.792734288E12, 44728.0], [1.792734287E12, 45629.0], [1.792734289E12, 45145.0], [1.79273428E12, 15382.0], [1.79273429E12, 19868.0], [1.792734281E12, 51968.0], [1.792734282E12, 47905.0]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.792734284E12, 40897.0], [1.792734283E12, 34482.0], [1.792734285E12, 39022.0], [1.792734286E12, 37536.0], [1.792734288E12, 37501.0], [1.792734287E12, 38256.0], [1.792734289E12, 37845.0], [1.79273428E12, 12900.0], [1.79273429E12, 16656.0], [1.792734281E12, 43573.0], [1.792734282E12, 40167.0]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.79273429E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 29.71844660194175, "minX": 1.79273428E12, "maxY": 325.61764705882354, "series": [{"data": [[1.792734284E12, 54.870370370370395], [1.792734283E12, 81.58241758241759], [1.792734285E12, 29.71844660194175], [1.792734286E12, 40.181818181818166], [1.792734288E12, 34.75757575757577], [1.792734287E12, 30.247524752475258], [1.792734289E12, 30.029999999999994], [1.79273428E12, 325.61764705882354], [1.79273429E12, 36.068181818181806], [1.792734281E12, 190.2434782608695], [1.792734282E12, 46.52830188679243]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.79273429E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 29.708737864077673, "minX": 1.79273428E12, "maxY": 325.47058823529403, "series": [{"data": [[1.792734284E12, 54.85185185185186], [1.792734283E12, 81.57142857142856], [1.792734285E12, 29.708737864077673], [1.792734286E12, 40.161616161616166], [1.792734288E12, 34.75757575757577], [1.792734287E12, 30.23762376237624], [1.792734289E12, 30.020000000000007], [1.79273428E12, 325.47058823529403], [1.79273429E12, 36.068181818181806], [1.792734281E12, 190.22608695652164], [1.792734282E12, 46.52830188679243]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.79273429E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.25999999999999995, "minX": 1.79273428E12, "maxY": 7.500000000000002, "series": [{"data": [[1.792734284E12, 0.4537037037037037], [1.792734283E12, 0.3736263736263736], [1.792734285E12, 0.3592233009708739], [1.792734286E12, 0.4141414141414141], [1.792734288E12, 0.3636363636363635], [1.792734287E12, 0.30693069306930715], [1.792734289E12, 0.25999999999999995], [1.79273428E12, 7.500000000000002], [1.79273429E12, 0.4318181818181817], [1.792734281E12, 0.6260869565217392], [1.792734282E12, 0.3962264150943397]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.79273429E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 20.0, "minX": 1.79273428E12, "maxY": 453.0, "series": [{"data": [[1.792734284E12, 153.0], [1.792734283E12, 192.0], [1.792734285E12, 46.0], [1.792734286E12, 93.0], [1.792734288E12, 68.0], [1.792734287E12, 53.0], [1.792734289E12, 47.0], [1.79273428E12, 453.0], [1.79273429E12, 68.0], [1.792734281E12, 325.0], [1.792734282E12, 127.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.792734284E12, 23.0], [1.792734283E12, 23.0], [1.792734285E12, 21.0], [1.792734286E12, 22.0], [1.792734288E12, 21.0], [1.792734287E12, 22.0], [1.792734289E12, 22.0], [1.79273428E12, 210.0], [1.79273429E12, 20.0], [1.792734281E12, 74.0], [1.792734282E12, 20.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.792734284E12, 102.20000000000002], [1.792734283E12, 161.0], [1.792734285E12, 37.0], [1.792734286E12, 67.0], [1.792734288E12, 48.0], [1.792734287E12, 40.8], [1.792734289E12, 37.900000000000006], [1.79273428E12, 443.5], [1.79273429E12, 49.0], [1.792734281E12, 257.20000000000005], [1.792734282E12, 80.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.792734284E12, 152.36999999999998], [1.792734283E12, 192.0], [1.792734285E12, 46.0], [1.792734286E12, 93.0], [1.792734288E12, 68.0], [1.792734287E12, 52.96000000000001], [1.792734289E12, 46.97999999999999], [1.79273428E12, 453.0], [1.79273429E12, 68.0], [1.792734281E12, 324.52], [1.792734282E12, 126.78999999999998]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.792734284E12, 40.5], [1.792734283E12, 77.0], [1.792734285E12, 28.0], [1.792734286E12, 33.0], [1.792734288E12, 33.0], [1.792734287E12, 27.0], [1.792734289E12, 30.0], [1.79273428E12, 301.0], [1.79273429E12, 35.0], [1.792734281E12, 193.0], [1.792734282E12, 38.0]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.792734284E12, 119.24999999999996], [1.792734283E12, 171.99999999999994], [1.792734285E12, 40.39999999999999], [1.792734286E12, 78.0], [1.792734288E12, 51.0], [1.792734287E12, 44.699999999999974], [1.792734289E12, 41.0], [1.79273428E12, 451.5], [1.79273429E12, 62.75], [1.792734281E12, 279.4], [1.792734282E12, 92.24999999999996]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.79273429E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 27.0, "minX": 34.0, "maxY": 301.0, "series": [{"data": [[34.0, 301.0], [91.0, 77.0], [44.0, 35.0], [99.0, 33.0], [103.0, 28.0], [101.0, 27.0], [100.0, 30.0], [106.0, 38.0], [108.0, 40.5], [115.0, 193.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 115.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 27.0, "minX": 34.0, "maxY": 301.0, "series": [{"data": [[34.0, 301.0], [91.0, 77.0], [44.0, 35.0], [99.0, 33.0], [103.0, 28.0], [101.0, 27.0], [100.0, 30.0], [106.0, 38.0], [108.0, 40.5], [115.0, 193.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 115.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 41.0, "minX": 1.79273428E12, "maxY": 100.0, "series": [{"data": [[1.792734284E12, 100.0], [1.792734283E12, 100.0], [1.792734285E12, 100.0], [1.792734286E12, 100.0], [1.792734288E12, 100.0], [1.792734287E12, 100.0], [1.792734289E12, 100.0], [1.79273428E12, 59.0], [1.79273429E12, 41.0], [1.792734281E12, 100.0], [1.792734282E12, 100.0]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.79273429E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 34.0, "minX": 1.79273428E12, "maxY": 115.0, "series": [{"data": [[1.792734284E12, 108.0], [1.792734283E12, 91.0], [1.792734285E12, 103.0], [1.792734286E12, 99.0], [1.792734288E12, 99.0], [1.792734287E12, 101.0], [1.792734289E12, 100.0], [1.79273428E12, 34.0], [1.79273429E12, 44.0], [1.792734281E12, 115.0], [1.792734282E12, 106.0]], "isOverall": false, "label": "201", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.79273429E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 34.0, "minX": 1.79273428E12, "maxY": 115.0, "series": [{"data": [[1.792734284E12, 108.0], [1.792734283E12, 91.0], [1.792734285E12, 103.0], [1.792734286E12, 99.0], [1.792734288E12, 99.0], [1.792734287E12, 101.0], [1.792734289E12, 100.0], [1.79273428E12, 34.0], [1.79273429E12, 44.0], [1.792734281E12, 115.0], [1.792734282E12, 106.0]], "isOverall": false, "label": "HTTP Request-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.79273429E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 34.0, "minX": 1.79273428E12, "maxY": 115.0, "series": [{"data": [[1.792734284E12, 108.0], [1.792734283E12, 91.0], [1.792734285E12, 103.0], [1.792734286E12, 99.0], [1.792734288E12, 99.0], [1.792734287E12, 101.0], [1.792734289E12, 100.0], [1.79273428E12, 34.0], [1.79273429E12, 44.0], [1.792734281E12, 115.0], [1.792734282E12, 106.0]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.79273429E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

