/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 19.0, "minX": 0.0, "maxY": 529.0, "series": [{"data": [[0.0, 19.0], [0.1, 19.0], [0.2, 20.0], [0.3, 20.0], [0.4, 20.0], [0.5, 20.0], [0.6, 21.0], [0.7, 21.0], [0.8, 21.0], [0.9, 21.0], [1.0, 21.0], [1.1, 21.0], [1.2, 21.0], [1.3, 21.0], [1.4, 21.0], [1.5, 21.0], [1.6, 21.0], [1.7, 21.0], [1.8, 22.0], [1.9, 22.0], [2.0, 22.0], [2.1, 22.0], [2.2, 22.0], [2.3, 22.0], [2.4, 22.0], [2.5, 22.0], [2.6, 22.0], [2.7, 22.0], [2.8, 22.0], [2.9, 22.0], [3.0, 22.0], [3.1, 22.0], [3.2, 22.0], [3.3, 22.0], [3.4, 22.0], [3.5, 22.0], [3.6, 22.0], [3.7, 22.0], [3.8, 22.0], [3.9, 22.0], [4.0, 22.0], [4.1, 22.0], [4.2, 22.0], [4.3, 22.0], [4.4, 22.0], [4.5, 22.0], [4.6, 22.0], [4.7, 22.0], [4.8, 22.0], [4.9, 22.0], [5.0, 22.0], [5.1, 22.0], [5.2, 22.0], [5.3, 22.0], [5.4, 22.0], [5.5, 22.0], [5.6, 22.0], [5.7, 22.0], [5.8, 22.0], [5.9, 22.0], [6.0, 22.0], [6.1, 22.0], [6.2, 22.0], [6.3, 22.0], [6.4, 22.0], [6.5, 23.0], [6.6, 23.0], [6.7, 23.0], [6.8, 23.0], [6.9, 23.0], [7.0, 23.0], [7.1, 23.0], [7.2, 23.0], [7.3, 23.0], [7.4, 23.0], [7.5, 23.0], [7.6, 23.0], [7.7, 23.0], [7.8, 23.0], [7.9, 23.0], [8.0, 23.0], [8.1, 23.0], [8.2, 23.0], [8.3, 23.0], [8.4, 23.0], [8.5, 23.0], [8.6, 23.0], [8.7, 23.0], [8.8, 23.0], [8.9, 23.0], [9.0, 23.0], [9.1, 23.0], [9.2, 23.0], [9.3, 23.0], [9.4, 23.0], [9.5, 23.0], [9.6, 23.0], [9.7, 23.0], [9.8, 24.0], [9.9, 24.0], [10.0, 24.0], [10.1, 24.0], [10.2, 24.0], [10.3, 24.0], [10.4, 24.0], [10.5, 24.0], [10.6, 24.0], [10.7, 24.0], [10.8, 24.0], [10.9, 24.0], [11.0, 24.0], [11.1, 25.0], [11.2, 25.0], [11.3, 25.0], [11.4, 25.0], [11.5, 25.0], [11.6, 25.0], [11.7, 25.0], [11.8, 25.0], [11.9, 25.0], [12.0, 25.0], [12.1, 25.0], [12.2, 25.0], [12.3, 25.0], [12.4, 25.0], [12.5, 25.0], [12.6, 25.0], [12.7, 25.0], [12.8, 25.0], [12.9, 25.0], [13.0, 25.0], [13.1, 25.0], [13.2, 25.0], [13.3, 25.0], [13.4, 25.0], [13.5, 25.0], [13.6, 25.0], [13.7, 25.0], [13.8, 25.0], [13.9, 25.0], [14.0, 25.0], [14.1, 25.0], [14.2, 25.0], [14.3, 25.0], [14.4, 25.0], [14.5, 25.0], [14.6, 25.0], [14.7, 25.0], [14.8, 25.0], [14.9, 25.0], [15.0, 25.0], [15.1, 25.0], [15.2, 25.0], [15.3, 25.0], [15.4, 25.0], [15.5, 25.0], [15.6, 25.0], [15.7, 25.0], [15.8, 25.0], [15.9, 25.0], [16.0, 25.0], [16.1, 25.0], [16.2, 25.0], [16.3, 25.0], [16.4, 25.0], [16.5, 25.0], [16.6, 25.0], [16.7, 25.0], [16.8, 25.0], [16.9, 25.0], [17.0, 25.0], [17.1, 25.0], [17.2, 25.0], [17.3, 25.0], [17.4, 25.0], [17.5, 25.0], [17.6, 25.0], [17.7, 25.0], [17.8, 25.0], [17.9, 25.0], [18.0, 25.0], [18.1, 25.0], [18.2, 25.0], [18.3, 25.0], [18.4, 25.0], [18.5, 25.0], [18.6, 25.0], [18.7, 25.0], [18.8, 26.0], [18.9, 26.0], [19.0, 26.0], [19.1, 26.0], [19.2, 26.0], [19.3, 26.0], [19.4, 26.0], [19.5, 26.0], [19.6, 26.0], [19.7, 26.0], [19.8, 26.0], [19.9, 26.0], [20.0, 26.0], [20.1, 26.0], [20.2, 26.0], [20.3, 26.0], [20.4, 26.0], [20.5, 26.0], [20.6, 26.0], [20.7, 26.0], [20.8, 26.0], [20.9, 26.0], [21.0, 26.0], [21.1, 26.0], [21.2, 26.0], [21.3, 26.0], [21.4, 26.0], [21.5, 26.0], [21.6, 26.0], [21.7, 26.0], [21.8, 26.0], [21.9, 26.0], [22.0, 26.0], [22.1, 26.0], [22.2, 26.0], [22.3, 26.0], [22.4, 26.0], [22.5, 26.0], [22.6, 26.0], [22.7, 26.0], [22.8, 26.0], [22.9, 26.0], [23.0, 26.0], [23.1, 26.0], [23.2, 26.0], [23.3, 26.0], [23.4, 26.0], [23.5, 26.0], [23.6, 26.0], [23.7, 26.0], [23.8, 26.0], [23.9, 26.0], [24.0, 26.0], [24.1, 26.0], [24.2, 26.0], [24.3, 26.0], [24.4, 26.0], [24.5, 26.0], [24.6, 26.0], [24.7, 26.0], [24.8, 26.0], [24.9, 26.0], [25.0, 26.0], [25.1, 26.0], [25.2, 26.0], [25.3, 26.0], [25.4, 26.0], [25.5, 27.0], [25.6, 27.0], [25.7, 27.0], [25.8, 27.0], [25.9, 27.0], [26.0, 27.0], [26.1, 27.0], [26.2, 27.0], [26.3, 27.0], [26.4, 27.0], [26.5, 27.0], [26.6, 27.0], [26.7, 27.0], [26.8, 27.0], [26.9, 27.0], [27.0, 27.0], [27.1, 27.0], [27.2, 27.0], [27.3, 27.0], [27.4, 27.0], [27.5, 27.0], [27.6, 27.0], [27.7, 28.0], [27.8, 28.0], [27.9, 28.0], [28.0, 28.0], [28.1, 28.0], [28.2, 28.0], [28.3, 28.0], [28.4, 28.0], [28.5, 28.0], [28.6, 28.0], [28.7, 28.0], [28.8, 28.0], [28.9, 28.0], [29.0, 28.0], [29.1, 28.0], [29.2, 28.0], [29.3, 29.0], [29.4, 29.0], [29.5, 29.0], [29.6, 29.0], [29.7, 29.0], [29.8, 29.0], [29.9, 29.0], [30.0, 29.0], [30.1, 29.0], [30.2, 29.0], [30.3, 29.0], [30.4, 29.0], [30.5, 29.0], [30.6, 29.0], [30.7, 29.0], [30.8, 29.0], [30.9, 29.0], [31.0, 29.0], [31.1, 29.0], [31.2, 30.0], [31.3, 30.0], [31.4, 30.0], [31.5, 30.0], [31.6, 30.0], [31.7, 30.0], [31.8, 30.0], [31.9, 30.0], [32.0, 30.0], [32.1, 30.0], [32.2, 30.0], [32.3, 30.0], [32.4, 30.0], [32.5, 30.0], [32.6, 30.0], [32.7, 30.0], [32.8, 30.0], [32.9, 30.0], [33.0, 30.0], [33.1, 30.0], [33.2, 30.0], [33.3, 30.0], [33.4, 30.0], [33.5, 30.0], [33.6, 30.0], [33.7, 30.0], [33.8, 30.0], [33.9, 30.0], [34.0, 30.0], [34.1, 30.0], [34.2, 31.0], [34.3, 31.0], [34.4, 31.0], [34.5, 31.0], [34.6, 31.0], [34.7, 31.0], [34.8, 31.0], [34.9, 31.0], [35.0, 31.0], [35.1, 31.0], [35.2, 31.0], [35.3, 31.0], [35.4, 31.0], [35.5, 31.0], [35.6, 31.0], [35.7, 31.0], [35.8, 31.0], [35.9, 31.0], [36.0, 31.0], [36.1, 31.0], [36.2, 31.0], [36.3, 31.0], [36.4, 31.0], [36.5, 31.0], [36.6, 31.0], [36.7, 31.0], [36.8, 31.0], [36.9, 31.0], [37.0, 31.0], [37.1, 31.0], [37.2, 31.0], [37.3, 31.0], [37.4, 31.0], [37.5, 31.0], [37.6, 31.0], [37.7, 31.0], [37.8, 31.0], [37.9, 31.0], [38.0, 31.0], [38.1, 31.0], [38.2, 32.0], [38.3, 32.0], [38.4, 32.0], [38.5, 32.0], [38.6, 32.0], [38.7, 32.0], [38.8, 32.0], [38.9, 32.0], [39.0, 32.0], [39.1, 32.0], [39.2, 32.0], [39.3, 32.0], [39.4, 32.0], [39.5, 32.0], [39.6, 32.0], [39.7, 32.0], [39.8, 32.0], [39.9, 32.0], [40.0, 32.0], [40.1, 32.0], [40.2, 32.0], [40.3, 32.0], [40.4, 32.0], [40.5, 32.0], [40.6, 32.0], [40.7, 32.0], [40.8, 32.0], [40.9, 32.0], [41.0, 32.0], [41.1, 32.0], [41.2, 32.0], [41.3, 32.0], [41.4, 32.0], [41.5, 32.0], [41.6, 32.0], [41.7, 32.0], [41.8, 32.0], [41.9, 32.0], [42.0, 32.0], [42.1, 32.0], [42.2, 32.0], [42.3, 32.0], [42.4, 32.0], [42.5, 32.0], [42.6, 32.0], [42.7, 32.0], [42.8, 33.0], [42.9, 33.0], [43.0, 33.0], [43.1, 33.0], [43.2, 33.0], [43.3, 33.0], [43.4, 33.0], [43.5, 33.0], [43.6, 33.0], [43.7, 33.0], [43.8, 33.0], [43.9, 33.0], [44.0, 33.0], [44.1, 33.0], [44.2, 33.0], [44.3, 33.0], [44.4, 33.0], [44.5, 33.0], [44.6, 33.0], [44.7, 33.0], [44.8, 33.0], [44.9, 33.0], [45.0, 33.0], [45.1, 33.0], [45.2, 33.0], [45.3, 33.0], [45.4, 33.0], [45.5, 33.0], [45.6, 33.0], [45.7, 33.0], [45.8, 33.0], [45.9, 33.0], [46.0, 33.0], [46.1, 33.0], [46.2, 33.0], [46.3, 33.0], [46.4, 33.0], [46.5, 33.0], [46.6, 33.0], [46.7, 33.0], [46.8, 33.0], [46.9, 33.0], [47.0, 33.0], [47.1, 33.0], [47.2, 33.0], [47.3, 33.0], [47.4, 33.0], [47.5, 33.0], [47.6, 34.0], [47.7, 34.0], [47.8, 34.0], [47.9, 34.0], [48.0, 34.0], [48.1, 34.0], [48.2, 34.0], [48.3, 34.0], [48.4, 34.0], [48.5, 34.0], [48.6, 34.0], [48.7, 34.0], [48.8, 34.0], [48.9, 34.0], [49.0, 34.0], [49.1, 34.0], [49.2, 34.0], [49.3, 34.0], [49.4, 34.0], [49.5, 34.0], [49.6, 34.0], [49.7, 34.0], [49.8, 34.0], [49.9, 34.0], [50.0, 34.0], [50.1, 34.0], [50.2, 34.0], [50.3, 34.0], [50.4, 34.0], [50.5, 34.0], [50.6, 34.0], [50.7, 34.0], [50.8, 34.0], [50.9, 34.0], [51.0, 34.0], [51.1, 34.0], [51.2, 34.0], [51.3, 34.0], [51.4, 35.0], [51.5, 35.0], [51.6, 35.0], [51.7, 35.0], [51.8, 35.0], [51.9, 35.0], [52.0, 35.0], [52.1, 35.0], [52.2, 35.0], [52.3, 35.0], [52.4, 35.0], [52.5, 35.0], [52.6, 35.0], [52.7, 35.0], [52.8, 35.0], [52.9, 35.0], [53.0, 35.0], [53.1, 35.0], [53.2, 35.0], [53.3, 35.0], [53.4, 35.0], [53.5, 35.0], [53.6, 35.0], [53.7, 35.0], [53.8, 35.0], [53.9, 35.0], [54.0, 35.0], [54.1, 35.0], [54.2, 35.0], [54.3, 35.0], [54.4, 35.0], [54.5, 35.0], [54.6, 35.0], [54.7, 35.0], [54.8, 35.0], [54.9, 35.0], [55.0, 35.0], [55.1, 35.0], [55.2, 35.0], [55.3, 35.0], [55.4, 35.0], [55.5, 35.0], [55.6, 35.0], [55.7, 35.0], [55.8, 35.0], [55.9, 35.0], [56.0, 35.0], [56.1, 35.0], [56.2, 35.0], [56.3, 35.0], [56.4, 35.0], [56.5, 35.0], [56.6, 36.0], [56.7, 36.0], [56.8, 36.0], [56.9, 36.0], [57.0, 36.0], [57.1, 36.0], [57.2, 36.0], [57.3, 36.0], [57.4, 36.0], [57.5, 36.0], [57.6, 36.0], [57.7, 36.0], [57.8, 36.0], [57.9, 36.0], [58.0, 36.0], [58.1, 36.0], [58.2, 36.0], [58.3, 36.0], [58.4, 36.0], [58.5, 36.0], [58.6, 36.0], [58.7, 36.0], [58.8, 36.0], [58.9, 36.0], [59.0, 36.0], [59.1, 36.0], [59.2, 36.0], [59.3, 36.0], [59.4, 36.0], [59.5, 36.0], [59.6, 36.0], [59.7, 36.0], [59.8, 36.0], [59.9, 36.0], [60.0, 36.0], [60.1, 37.0], [60.2, 37.0], [60.3, 37.0], [60.4, 37.0], [60.5, 37.0], [60.6, 37.0], [60.7, 37.0], [60.8, 37.0], [60.9, 37.0], [61.0, 37.0], [61.1, 37.0], [61.2, 37.0], [61.3, 37.0], [61.4, 37.0], [61.5, 37.0], [61.6, 37.0], [61.7, 37.0], [61.8, 37.0], [61.9, 37.0], [62.0, 37.0], [62.1, 37.0], [62.2, 37.0], [62.3, 37.0], [62.4, 37.0], [62.5, 37.0], [62.6, 37.0], [62.7, 37.0], [62.8, 37.0], [62.9, 37.0], [63.0, 38.0], [63.1, 38.0], [63.2, 38.0], [63.3, 38.0], [63.4, 38.0], [63.5, 38.0], [63.6, 38.0], [63.7, 38.0], [63.8, 38.0], [63.9, 38.0], [64.0, 38.0], [64.1, 38.0], [64.2, 38.0], [64.3, 38.0], [64.4, 38.0], [64.5, 38.0], [64.6, 38.0], [64.7, 38.0], [64.8, 38.0], [64.9, 38.0], [65.0, 38.0], [65.1, 38.0], [65.2, 38.0], [65.3, 39.0], [65.4, 39.0], [65.5, 39.0], [65.6, 39.0], [65.7, 39.0], [65.8, 39.0], [65.9, 39.0], [66.0, 39.0], [66.1, 39.0], [66.2, 39.0], [66.3, 39.0], [66.4, 39.0], [66.5, 39.0], [66.6, 39.0], [66.7, 39.0], [66.8, 40.0], [66.9, 40.0], [67.0, 40.0], [67.1, 40.0], [67.2, 40.0], [67.3, 40.0], [67.4, 40.0], [67.5, 40.0], [67.6, 40.0], [67.7, 40.0], [67.8, 40.0], [67.9, 40.0], [68.0, 40.0], [68.1, 40.0], [68.2, 41.0], [68.3, 41.0], [68.4, 41.0], [68.5, 41.0], [68.6, 41.0], [68.7, 41.0], [68.8, 41.0], [68.9, 41.0], [69.0, 41.0], [69.1, 41.0], [69.2, 41.0], [69.3, 41.0], [69.4, 41.0], [69.5, 41.0], [69.6, 41.0], [69.7, 41.0], [69.8, 42.0], [69.9, 42.0], [70.0, 42.0], [70.1, 42.0], [70.2, 42.0], [70.3, 42.0], [70.4, 42.0], [70.5, 42.0], [70.6, 42.0], [70.7, 42.0], [70.8, 43.0], [70.9, 43.0], [71.0, 43.0], [71.1, 43.0], [71.2, 43.0], [71.3, 43.0], [71.4, 43.0], [71.5, 44.0], [71.6, 44.0], [71.7, 44.0], [71.8, 44.0], [71.9, 44.0], [72.0, 44.0], [72.1, 44.0], [72.2, 44.0], [72.3, 44.0], [72.4, 45.0], [72.5, 45.0], [72.6, 45.0], [72.7, 45.0], [72.8, 45.0], [72.9, 45.0], [73.0, 45.0], [73.1, 46.0], [73.2, 46.0], [73.3, 46.0], [73.4, 46.0], [73.5, 46.0], [73.6, 46.0], [73.7, 46.0], [73.8, 46.0], [73.9, 46.0], [74.0, 47.0], [74.1, 47.0], [74.2, 47.0], [74.3, 47.0], [74.4, 48.0], [74.5, 49.0], [74.6, 49.0], [74.7, 49.0], [74.8, 50.0], [74.9, 50.0], [75.0, 50.0], [75.1, 50.0], [75.2, 51.0], [75.3, 51.0], [75.4, 51.0], [75.5, 51.0], [75.6, 51.0], [75.7, 54.0], [75.8, 54.0], [75.9, 55.0], [76.0, 55.0], [76.1, 55.0], [76.2, 55.0], [76.3, 55.0], [76.4, 56.0], [76.5, 56.0], [76.6, 57.0], [76.7, 57.0], [76.8, 57.0], [76.9, 57.0], [77.0, 58.0], [77.1, 58.0], [77.2, 60.0], [77.3, 61.0], [77.4, 62.0], [77.5, 62.0], [77.6, 62.0], [77.7, 62.0], [77.8, 63.0], [77.9, 65.0], [78.0, 67.0], [78.1, 67.0], [78.2, 68.0], [78.3, 68.0], [78.4, 69.0], [78.5, 71.0], [78.6, 72.0], [78.7, 74.0], [78.8, 75.0], [78.9, 75.0], [79.0, 76.0], [79.1, 79.0], [79.2, 80.0], [79.3, 82.0], [79.4, 82.0], [79.5, 83.0], [79.6, 83.0], [79.7, 85.0], [79.8, 85.0], [79.9, 85.0], [80.0, 86.0], [80.1, 86.0], [80.2, 86.0], [80.3, 86.0], [80.4, 86.0], [80.5, 86.0], [80.6, 91.0], [80.7, 92.0], [80.8, 94.0], [80.9, 94.0], [81.0, 95.0], [81.1, 97.0], [81.2, 99.0], [81.3, 106.0], [81.4, 106.0], [81.5, 106.0], [81.6, 107.0], [81.7, 116.0], [81.8, 116.0], [81.9, 117.0], [82.0, 123.0], [82.1, 126.0], [82.2, 128.0], [82.3, 129.0], [82.4, 135.0], [82.5, 136.0], [82.6, 139.0], [82.7, 147.0], [82.8, 148.0], [82.9, 150.0], [83.0, 152.0], [83.1, 155.0], [83.2, 156.0], [83.3, 159.0], [83.4, 160.0], [83.5, 160.0], [83.6, 161.0], [83.7, 163.0], [83.8, 163.0], [83.9, 164.0], [84.0, 164.0], [84.1, 164.0], [84.2, 164.0], [84.3, 165.0], [84.4, 165.0], [84.5, 165.0], [84.6, 166.0], [84.7, 171.0], [84.8, 171.0], [84.9, 172.0], [85.0, 176.0], [85.1, 176.0], [85.2, 177.0], [85.3, 177.0], [85.4, 179.0], [85.5, 180.0], [85.6, 180.0], [85.7, 180.0], [85.8, 182.0], [85.9, 187.0], [86.0, 188.0], [86.1, 189.0], [86.2, 193.0], [86.3, 193.0], [86.4, 194.0], [86.5, 197.0], [86.6, 199.0], [86.7, 200.0], [86.8, 201.0], [86.9, 201.0], [87.0, 202.0], [87.1, 204.0], [87.2, 205.0], [87.3, 205.0], [87.4, 209.0], [87.5, 209.0], [87.6, 210.0], [87.7, 211.0], [87.8, 212.0], [87.9, 215.0], [88.0, 215.0], [88.1, 215.0], [88.2, 216.0], [88.3, 219.0], [88.4, 221.0], [88.5, 225.0], [88.6, 225.0], [88.7, 226.0], [88.8, 226.0], [88.9, 230.0], [89.0, 231.0], [89.1, 236.0], [89.2, 237.0], [89.3, 237.0], [89.4, 237.0], [89.5, 238.0], [89.6, 241.0], [89.7, 244.0], [89.8, 244.0], [89.9, 248.0], [90.0, 250.0], [90.1, 250.0], [90.2, 252.0], [90.3, 255.0], [90.4, 259.0], [90.5, 259.0], [90.6, 261.0], [90.7, 268.0], [90.8, 270.0], [90.9, 270.0], [91.0, 271.0], [91.1, 273.0], [91.2, 273.0], [91.3, 275.0], [91.4, 275.0], [91.5, 276.0], [91.6, 277.0], [91.7, 278.0], [91.8, 280.0], [91.9, 281.0], [92.0, 282.0], [92.1, 282.0], [92.2, 283.0], [92.3, 283.0], [92.4, 285.0], [92.5, 288.0], [92.6, 288.0], [92.7, 288.0], [92.8, 290.0], [92.9, 291.0], [93.0, 292.0], [93.1, 293.0], [93.2, 293.0], [93.3, 293.0], [93.4, 295.0], [93.5, 296.0], [93.6, 297.0], [93.7, 298.0], [93.8, 298.0], [93.9, 299.0], [94.0, 300.0], [94.1, 302.0], [94.2, 305.0], [94.3, 306.0], [94.4, 308.0], [94.5, 308.0], [94.6, 309.0], [94.7, 309.0], [94.8, 311.0], [94.9, 312.0], [95.0, 313.0], [95.1, 313.0], [95.2, 316.0], [95.3, 316.0], [95.4, 318.0], [95.5, 318.0], [95.6, 320.0], [95.7, 324.0], [95.8, 330.0], [95.9, 332.0], [96.0, 332.0], [96.1, 332.0], [96.2, 335.0], [96.3, 336.0], [96.4, 344.0], [96.5, 350.0], [96.6, 351.0], [96.7, 351.0], [96.8, 356.0], [96.9, 359.0], [97.0, 363.0], [97.1, 368.0], [97.2, 369.0], [97.3, 370.0], [97.4, 371.0], [97.5, 371.0], [97.6, 372.0], [97.7, 372.0], [97.8, 373.0], [97.9, 376.0], [98.0, 377.0], [98.1, 382.0], [98.2, 384.0], [98.3, 387.0], [98.4, 388.0], [98.5, 388.0], [98.6, 389.0], [98.7, 397.0], [98.8, 407.0], [98.9, 454.0], [99.0, 461.0], [99.1, 463.0], [99.2, 467.0], [99.3, 472.0], [99.4, 504.0], [99.5, 512.0], [99.6, 520.0], [99.7, 521.0], [99.8, 523.0], [99.9, 529.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 6.0, "minX": 0.0, "maxY": 792.0, "series": [{"data": [[0.0, 792.0], [300.0, 47.0], [400.0, 6.0], [200.0, 71.0], [100.0, 53.0], [500.0, 6.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 500.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 6.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 969.0, "series": [{"data": [[0.0, 969.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 6.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 1.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 3.5400000000000005, "minX": 1.792734443E12, "maxY": 39.535714285714306, "series": [{"data": [[1.792734444E12, 23.03389830508475], [1.792734443E12, 39.535714285714306], [1.792734445E12, 6.046296296296296], [1.792734446E12, 4.111111111111111], [1.792734448E12, 3.673267326732673], [1.792734447E12, 3.8415841584158428], [1.792734449E12, 3.5400000000000005], [1.79273445E12, 4.020408163265306], [1.792734452E12, 3.559139784946236], [1.792734451E12, 3.594059405940594]], "isOverall": false, "label": "Thread Group", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.792734452E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 19.0, "minX": 1.0, "maxY": 467.0, "series": [{"data": [[33.0, 335.25], [32.0, 282.75], [2.0, 21.88888888888889], [35.0, 421.5], [34.0, 329.2], [37.0, 458.5], [36.0, 370.0], [40.0, 463.5], [43.0, 467.0], [42.0, 402.0], [45.0, 428.0], [44.0, 335.0], [47.0, 372.5], [46.0, 410.25], [48.0, 424.5], [49.0, 403.5], [3.0, 26.091911764705866], [50.0, 366.125], [4.0, 34.48626373626373], [5.0, 40.4235294117647], [6.0, 51.33333333333333], [7.0, 54.18181818181819], [8.0, 83.0], [9.0, 84.83333333333334], [10.0, 90.0], [11.0, 125.5], [12.0, 102.55555555555556], [13.0, 141.25], [14.0, 116.0], [15.0, 163.33333333333334], [16.0, 149.0], [1.0, 19.0], [17.0, 160.5], [18.0, 185.33333333333334], [19.0, 172.28571428571428], [20.0, 210.5], [21.0, 218.33333333333334], [22.0, 206.1818181818182], [23.0, 229.14285714285714], [24.0, 205.0], [25.0, 194.0], [26.0, 260.33333333333337], [27.0, 272.0], [28.0, 272.6666666666667], [29.0, 313.875], [30.0, 288.7692307692308], [31.0, 307.61538461538464]], "isOverall": false, "label": "HTTP Request", "isController": false}, {"data": [[8.403076923076922, 77.34256410256414]], "isOverall": false, "label": "HTTP Request-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 50.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 21210.0, "minX": 1.792734443E12, "maxY": 53306.0, "series": [{"data": [[1.792734444E12, 53306.0], [1.792734443E12, 25298.0], [1.792734445E12, 48821.0], [1.792734446E12, 44702.0], [1.792734448E12, 45644.0], [1.792734447E12, 45622.0], [1.792734449E12, 45181.0], [1.79273445E12, 44283.0], [1.792734452E12, 42003.0], [1.792734451E12, 45641.0]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.792734444E12, 44692.0], [1.792734443E12, 21210.0], [1.792734445E12, 40937.0], [1.792734446E12, 37475.0], [1.792734448E12, 38271.0], [1.792734447E12, 38249.0], [1.792734449E12, 37881.0], [1.79273445E12, 37129.0], [1.792734452E12, 35214.0], [1.792734451E12, 38268.0]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.792734452E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 29.86, "minX": 1.792734443E12, "maxY": 368.10714285714283, "series": [{"data": [[1.792734444E12, 224.88135593220323], [1.792734443E12, 368.10714285714283], [1.792734445E12, 55.15740740740737], [1.792734446E12, 35.79797979797979], [1.792734448E12, 31.336633663366324], [1.792734447E12, 32.990099009901], [1.792734449E12, 29.86], [1.79273445E12, 34.49999999999999], [1.792734452E12, 30.021505376344084], [1.792734451E12, 30.712871287128714]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.792734452E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 29.849999999999994, "minX": 1.792734443E12, "maxY": 366.07142857142867, "series": [{"data": [[1.792734444E12, 224.85593220338978], [1.792734443E12, 366.07142857142867], [1.792734445E12, 55.138888888888864], [1.792734446E12, 35.787878787878775], [1.792734448E12, 31.336633663366324], [1.792734447E12, 32.98019801980197], [1.792734449E12, 29.849999999999994], [1.79273445E12, 34.48979591836736], [1.792734452E12, 30.010752688172044], [1.792734451E12, 30.712871287128714]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.792734452E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.3168316831683167, "minX": 1.792734443E12, "maxY": 6.160714285714287, "series": [{"data": [[1.792734444E12, 0.6271186440677967], [1.792734443E12, 6.160714285714287], [1.792734445E12, 0.4259259259259259], [1.792734446E12, 0.393939393939394], [1.792734448E12, 0.37623762376237607], [1.792734447E12, 0.36633663366336633], [1.792734449E12, 0.35], [1.79273445E12, 0.4387755102040817], [1.792734452E12, 0.3548387096774192], [1.792734451E12, 0.3168316831683167]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.792734452E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 19.0, "minX": 1.792734443E12, "maxY": 529.0, "series": [{"data": [[1.792734444E12, 373.0], [1.792734443E12, 529.0], [1.792734445E12, 171.0], [1.792734446E12, 94.0], [1.792734448E12, 50.0], [1.792734447E12, 56.0], [1.792734449E12, 47.0], [1.79273445E12, 63.0], [1.792734452E12, 55.0], [1.792734451E12, 48.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.792734444E12, 97.0], [1.792734443E12, 237.0], [1.792734445E12, 21.0], [1.792734446E12, 20.0], [1.792734448E12, 20.0], [1.792734447E12, 21.0], [1.792734449E12, 21.0], [1.79273445E12, 21.0], [1.792734452E12, 19.0], [1.792734451E12, 21.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.792734444E12, 305.1], [1.792734443E12, 506.40000000000003], [1.792734445E12, 99.70000000000006], [1.792734446E12, 57.0], [1.792734448E12, 40.0], [1.792734447E12, 41.0], [1.792734449E12, 36.900000000000006], [1.79273445E12, 47.300000000000026], [1.792734452E12, 37.0], [1.792734451E12, 39.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.792734444E12, 365.2100000000001], [1.792734443E12, 529.0], [1.792734445E12, 169.64999999999995], [1.792734446E12, 94.0], [1.792734448E12, 50.0], [1.792734447E12, 55.90000000000002], [1.792734449E12, 46.97999999999999], [1.79273445E12, 63.0], [1.792734452E12, 55.0], [1.792734451E12, 47.980000000000004]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.792734444E12, 217.5], [1.792734443E12, 365.5], [1.792734445E12, 39.0], [1.792734446E12, 33.0], [1.792734448E12, 32.0], [1.792734447E12, 33.0], [1.792734449E12, 30.0], [1.79273445E12, 34.0], [1.792734452E12, 30.0], [1.792734451E12, 31.0]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.792734444E12, 313.15], [1.792734443E12, 521.3], [1.792734445E12, 120.29999999999998], [1.792734446E12, 62.0], [1.792734448E12, 44.0], [1.792734447E12, 44.79999999999998], [1.792734449E12, 41.74999999999994], [1.79273445E12, 55.099999999999994], [1.792734452E12, 41.0], [1.792734451E12, 40.89999999999999]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.792734452E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 30.0, "minX": 56.0, "maxY": 365.5, "series": [{"data": [[93.0, 30.0], [99.0, 33.0], [98.0, 34.0], [101.0, 32.0], [100.0, 30.0], [108.0, 39.0], [56.0, 365.5], [118.0, 217.5]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 118.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 30.0, "minX": 56.0, "maxY": 356.0, "series": [{"data": [[93.0, 30.0], [99.0, 33.0], [98.0, 34.0], [101.0, 32.0], [100.0, 30.0], [108.0, 39.0], [56.0, 356.0], [118.0, 217.5]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 118.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 84.0, "minX": 1.792734443E12, "maxY": 101.0, "series": [{"data": [[1.792734444E12, 101.0], [1.792734443E12, 84.0], [1.792734445E12, 100.0], [1.792734446E12, 100.0], [1.792734448E12, 100.0], [1.792734447E12, 100.0], [1.792734449E12, 100.0], [1.79273445E12, 100.0], [1.792734452E12, 90.0], [1.792734451E12, 100.0]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.792734452E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 56.0, "minX": 1.792734443E12, "maxY": 118.0, "series": [{"data": [[1.792734444E12, 118.0], [1.792734443E12, 56.0], [1.792734445E12, 108.0], [1.792734446E12, 99.0], [1.792734448E12, 101.0], [1.792734447E12, 101.0], [1.792734449E12, 100.0], [1.79273445E12, 98.0], [1.792734452E12, 93.0], [1.792734451E12, 101.0]], "isOverall": false, "label": "201", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.792734452E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 56.0, "minX": 1.792734443E12, "maxY": 118.0, "series": [{"data": [[1.792734444E12, 118.0], [1.792734443E12, 56.0], [1.792734445E12, 108.0], [1.792734446E12, 99.0], [1.792734448E12, 101.0], [1.792734447E12, 101.0], [1.792734449E12, 100.0], [1.79273445E12, 98.0], [1.792734452E12, 93.0], [1.792734451E12, 101.0]], "isOverall": false, "label": "HTTP Request-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.792734452E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 56.0, "minX": 1.792734443E12, "maxY": 118.0, "series": [{"data": [[1.792734444E12, 118.0], [1.792734443E12, 56.0], [1.792734445E12, 108.0], [1.792734446E12, 99.0], [1.792734448E12, 101.0], [1.792734447E12, 101.0], [1.792734449E12, 100.0], [1.79273445E12, 98.0], [1.792734452E12, 93.0], [1.792734451E12, 101.0]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.792734452E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

