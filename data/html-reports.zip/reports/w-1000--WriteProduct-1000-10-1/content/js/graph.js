/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 19.0, "minX": 0.0, "maxY": 323.0, "series": [{"data": [[0.0, 19.0], [0.1, 21.0], [0.2, 21.0], [0.3, 21.0], [0.4, 22.0], [0.5, 22.0], [0.6, 22.0], [0.7, 22.0], [0.8, 22.0], [0.9, 22.0], [1.0, 22.0], [1.1, 22.0], [1.2, 22.0], [1.3, 22.0], [1.4, 22.0], [1.5, 22.0], [1.6, 22.0], [1.7, 22.0], [1.8, 22.0], [1.9, 22.0], [2.0, 22.0], [2.1, 22.0], [2.2, 22.0], [2.3, 22.0], [2.4, 22.0], [2.5, 23.0], [2.6, 23.0], [2.7, 23.0], [2.8, 23.0], [2.9, 23.0], [3.0, 23.0], [3.1, 23.0], [3.2, 23.0], [3.3, 23.0], [3.4, 23.0], [3.5, 23.0], [3.6, 23.0], [3.7, 23.0], [3.8, 23.0], [3.9, 23.0], [4.0, 23.0], [4.1, 23.0], [4.2, 23.0], [4.3, 23.0], [4.4, 23.0], [4.5, 23.0], [4.6, 23.0], [4.7, 24.0], [4.8, 24.0], [4.9, 24.0], [5.0, 24.0], [5.1, 24.0], [5.2, 24.0], [5.3, 24.0], [5.4, 24.0], [5.5, 24.0], [5.6, 24.0], [5.7, 24.0], [5.8, 24.0], [5.9, 24.0], [6.0, 24.0], [6.1, 24.0], [6.2, 24.0], [6.3, 24.0], [6.4, 24.0], [6.5, 24.0], [6.6, 25.0], [6.7, 25.0], [6.8, 25.0], [6.9, 25.0], [7.0, 25.0], [7.1, 25.0], [7.2, 25.0], [7.3, 25.0], [7.4, 25.0], [7.5, 25.0], [7.6, 25.0], [7.7, 25.0], [7.8, 25.0], [7.9, 25.0], [8.0, 25.0], [8.1, 25.0], [8.2, 25.0], [8.3, 25.0], [8.4, 25.0], [8.5, 25.0], [8.6, 25.0], [8.7, 25.0], [8.8, 25.0], [8.9, 25.0], [9.0, 25.0], [9.1, 25.0], [9.2, 25.0], [9.3, 25.0], [9.4, 25.0], [9.5, 26.0], [9.6, 26.0], [9.7, 26.0], [9.8, 26.0], [9.9, 26.0], [10.0, 26.0], [10.1, 26.0], [10.2, 26.0], [10.3, 26.0], [10.4, 26.0], [10.5, 26.0], [10.6, 26.0], [10.7, 26.0], [10.8, 26.0], [10.9, 26.0], [11.0, 26.0], [11.1, 26.0], [11.2, 26.0], [11.3, 26.0], [11.4, 26.0], [11.5, 26.0], [11.6, 26.0], [11.7, 26.0], [11.8, 26.0], [11.9, 26.0], [12.0, 26.0], [12.1, 26.0], [12.2, 26.0], [12.3, 26.0], [12.4, 26.0], [12.5, 26.0], [12.6, 26.0], [12.7, 26.0], [12.8, 26.0], [12.9, 26.0], [13.0, 26.0], [13.1, 26.0], [13.2, 26.0], [13.3, 26.0], [13.4, 26.0], [13.5, 26.0], [13.6, 27.0], [13.7, 27.0], [13.8, 27.0], [13.9, 27.0], [14.0, 27.0], [14.1, 27.0], [14.2, 27.0], [14.3, 27.0], [14.4, 27.0], [14.5, 27.0], [14.6, 27.0], [14.7, 27.0], [14.8, 27.0], [14.9, 27.0], [15.0, 27.0], [15.1, 27.0], [15.2, 27.0], [15.3, 27.0], [15.4, 27.0], [15.5, 27.0], [15.6, 27.0], [15.7, 27.0], [15.8, 27.0], [15.9, 27.0], [16.0, 27.0], [16.1, 27.0], [16.2, 27.0], [16.3, 27.0], [16.4, 27.0], [16.5, 27.0], [16.6, 27.0], [16.7, 27.0], [16.8, 28.0], [16.9, 28.0], [17.0, 28.0], [17.1, 28.0], [17.2, 28.0], [17.3, 28.0], [17.4, 28.0], [17.5, 28.0], [17.6, 28.0], [17.7, 28.0], [17.8, 28.0], [17.9, 28.0], [18.0, 28.0], [18.1, 28.0], [18.2, 28.0], [18.3, 28.0], [18.4, 28.0], [18.5, 28.0], [18.6, 28.0], [18.7, 28.0], [18.8, 28.0], [18.9, 28.0], [19.0, 28.0], [19.1, 28.0], [19.2, 28.0], [19.3, 28.0], [19.4, 28.0], [19.5, 29.0], [19.6, 29.0], [19.7, 29.0], [19.8, 29.0], [19.9, 29.0], [20.0, 29.0], [20.1, 29.0], [20.2, 29.0], [20.3, 29.0], [20.4, 29.0], [20.5, 29.0], [20.6, 29.0], [20.7, 29.0], [20.8, 29.0], [20.9, 29.0], [21.0, 29.0], [21.1, 29.0], [21.2, 29.0], [21.3, 29.0], [21.4, 29.0], [21.5, 29.0], [21.6, 29.0], [21.7, 29.0], [21.8, 29.0], [21.9, 30.0], [22.0, 30.0], [22.1, 30.0], [22.2, 30.0], [22.3, 30.0], [22.4, 30.0], [22.5, 30.0], [22.6, 30.0], [22.7, 30.0], [22.8, 30.0], [22.9, 30.0], [23.0, 30.0], [23.1, 30.0], [23.2, 30.0], [23.3, 30.0], [23.4, 30.0], [23.5, 30.0], [23.6, 30.0], [23.7, 30.0], [23.8, 30.0], [23.9, 30.0], [24.0, 30.0], [24.1, 30.0], [24.2, 30.0], [24.3, 31.0], [24.4, 31.0], [24.5, 31.0], [24.6, 31.0], [24.7, 31.0], [24.8, 31.0], [24.9, 31.0], [25.0, 31.0], [25.1, 31.0], [25.2, 31.0], [25.3, 31.0], [25.4, 31.0], [25.5, 31.0], [25.6, 31.0], [25.7, 31.0], [25.8, 31.0], [25.9, 31.0], [26.0, 31.0], [26.1, 31.0], [26.2, 31.0], [26.3, 31.0], [26.4, 31.0], [26.5, 31.0], [26.6, 32.0], [26.7, 32.0], [26.8, 32.0], [26.9, 32.0], [27.0, 32.0], [27.1, 32.0], [27.2, 32.0], [27.3, 32.0], [27.4, 32.0], [27.5, 32.0], [27.6, 32.0], [27.7, 32.0], [27.8, 32.0], [27.9, 32.0], [28.0, 32.0], [28.1, 32.0], [28.2, 32.0], [28.3, 32.0], [28.4, 32.0], [28.5, 32.0], [28.6, 32.0], [28.7, 32.0], [28.8, 32.0], [28.9, 32.0], [29.0, 32.0], [29.1, 32.0], [29.2, 32.0], [29.3, 32.0], [29.4, 32.0], [29.5, 32.0], [29.6, 32.0], [29.7, 32.0], [29.8, 32.0], [29.9, 32.0], [30.0, 32.0], [30.1, 32.0], [30.2, 32.0], [30.3, 32.0], [30.4, 32.0], [30.5, 32.0], [30.6, 32.0], [30.7, 33.0], [30.8, 33.0], [30.9, 33.0], [31.0, 33.0], [31.1, 33.0], [31.2, 33.0], [31.3, 33.0], [31.4, 33.0], [31.5, 33.0], [31.6, 33.0], [31.7, 33.0], [31.8, 33.0], [31.9, 33.0], [32.0, 33.0], [32.1, 33.0], [32.2, 33.0], [32.3, 33.0], [32.4, 33.0], [32.5, 33.0], [32.6, 33.0], [32.7, 33.0], [32.8, 33.0], [32.9, 33.0], [33.0, 33.0], [33.1, 33.0], [33.2, 33.0], [33.3, 33.0], [33.4, 33.0], [33.5, 33.0], [33.6, 33.0], [33.7, 33.0], [33.8, 33.0], [33.9, 33.0], [34.0, 33.0], [34.1, 33.0], [34.2, 33.0], [34.3, 33.0], [34.4, 33.0], [34.5, 33.0], [34.6, 33.0], [34.7, 33.0], [34.8, 33.0], [34.9, 33.0], [35.0, 33.0], [35.1, 33.0], [35.2, 33.0], [35.3, 33.0], [35.4, 33.0], [35.5, 33.0], [35.6, 33.0], [35.7, 33.0], [35.8, 33.0], [35.9, 33.0], [36.0, 33.0], [36.1, 33.0], [36.2, 33.0], [36.3, 34.0], [36.4, 34.0], [36.5, 34.0], [36.6, 34.0], [36.7, 34.0], [36.8, 34.0], [36.9, 34.0], [37.0, 34.0], [37.1, 34.0], [37.2, 34.0], [37.3, 34.0], [37.4, 34.0], [37.5, 34.0], [37.6, 34.0], [37.7, 34.0], [37.8, 34.0], [37.9, 34.0], [38.0, 34.0], [38.1, 34.0], [38.2, 34.0], [38.3, 34.0], [38.4, 34.0], [38.5, 34.0], [38.6, 34.0], [38.7, 34.0], [38.8, 34.0], [38.9, 34.0], [39.0, 34.0], [39.1, 34.0], [39.2, 34.0], [39.3, 34.0], [39.4, 34.0], [39.5, 34.0], [39.6, 34.0], [39.7, 34.0], [39.8, 34.0], [39.9, 34.0], [40.0, 34.0], [40.1, 34.0], [40.2, 34.0], [40.3, 34.0], [40.4, 34.0], [40.5, 34.0], [40.6, 34.0], [40.7, 34.0], [40.8, 34.0], [40.9, 34.0], [41.0, 35.0], [41.1, 35.0], [41.2, 35.0], [41.3, 35.0], [41.4, 35.0], [41.5, 35.0], [41.6, 35.0], [41.7, 35.0], [41.8, 35.0], [41.9, 35.0], [42.0, 35.0], [42.1, 35.0], [42.2, 35.0], [42.3, 35.0], [42.4, 35.0], [42.5, 35.0], [42.6, 35.0], [42.7, 35.0], [42.8, 35.0], [42.9, 35.0], [43.0, 35.0], [43.1, 35.0], [43.2, 35.0], [43.3, 35.0], [43.4, 35.0], [43.5, 35.0], [43.6, 35.0], [43.7, 35.0], [43.8, 35.0], [43.9, 35.0], [44.0, 35.0], [44.1, 35.0], [44.2, 35.0], [44.3, 35.0], [44.4, 35.0], [44.5, 35.0], [44.6, 35.0], [44.7, 35.0], [44.8, 35.0], [44.9, 35.0], [45.0, 35.0], [45.1, 36.0], [45.2, 36.0], [45.3, 36.0], [45.4, 36.0], [45.5, 36.0], [45.6, 36.0], [45.7, 36.0], [45.8, 36.0], [45.9, 36.0], [46.0, 36.0], [46.1, 36.0], [46.2, 36.0], [46.3, 36.0], [46.4, 36.0], [46.5, 36.0], [46.6, 36.0], [46.7, 36.0], [46.8, 36.0], [46.9, 36.0], [47.0, 36.0], [47.1, 36.0], [47.2, 36.0], [47.3, 36.0], [47.4, 36.0], [47.5, 36.0], [47.6, 36.0], [47.7, 36.0], [47.8, 36.0], [47.9, 36.0], [48.0, 36.0], [48.1, 36.0], [48.2, 37.0], [48.3, 37.0], [48.4, 37.0], [48.5, 37.0], [48.6, 37.0], [48.7, 37.0], [48.8, 37.0], [48.9, 37.0], [49.0, 37.0], [49.1, 37.0], [49.2, 37.0], [49.3, 37.0], [49.4, 37.0], [49.5, 37.0], [49.6, 37.0], [49.7, 37.0], [49.8, 37.0], [49.9, 37.0], [50.0, 37.0], [50.1, 37.0], [50.2, 37.0], [50.3, 37.0], [50.4, 37.0], [50.5, 37.0], [50.6, 37.0], [50.7, 37.0], [50.8, 37.0], [50.9, 37.0], [51.0, 37.0], [51.1, 37.0], [51.2, 37.0], [51.3, 37.0], [51.4, 37.0], [51.5, 37.0], [51.6, 37.0], [51.7, 37.0], [51.8, 37.0], [51.9, 37.0], [52.0, 37.0], [52.1, 37.0], [52.2, 37.0], [52.3, 37.0], [52.4, 37.0], [52.5, 37.0], [52.6, 37.0], [52.7, 37.0], [52.8, 37.0], [52.9, 37.0], [53.0, 37.0], [53.1, 37.0], [53.2, 37.0], [53.3, 37.0], [53.4, 37.0], [53.5, 37.0], [53.6, 37.0], [53.7, 37.0], [53.8, 37.0], [53.9, 37.0], [54.0, 37.0], [54.1, 37.0], [54.2, 37.0], [54.3, 37.0], [54.4, 37.0], [54.5, 37.0], [54.6, 37.0], [54.7, 38.0], [54.8, 38.0], [54.9, 38.0], [55.0, 38.0], [55.1, 38.0], [55.2, 38.0], [55.3, 38.0], [55.4, 38.0], [55.5, 38.0], [55.6, 38.0], [55.7, 38.0], [55.8, 38.0], [55.9, 38.0], [56.0, 38.0], [56.1, 38.0], [56.2, 38.0], [56.3, 38.0], [56.4, 38.0], [56.5, 38.0], [56.6, 38.0], [56.7, 38.0], [56.8, 38.0], [56.9, 38.0], [57.0, 38.0], [57.1, 38.0], [57.2, 38.0], [57.3, 38.0], [57.4, 38.0], [57.5, 38.0], [57.6, 38.0], [57.7, 38.0], [57.8, 38.0], [57.9, 38.0], [58.0, 38.0], [58.1, 38.0], [58.2, 38.0], [58.3, 38.0], [58.4, 38.0], [58.5, 38.0], [58.6, 39.0], [58.7, 39.0], [58.8, 39.0], [58.9, 39.0], [59.0, 39.0], [59.1, 39.0], [59.2, 39.0], [59.3, 39.0], [59.4, 39.0], [59.5, 39.0], [59.6, 39.0], [59.7, 39.0], [59.8, 39.0], [59.9, 39.0], [60.0, 39.0], [60.1, 39.0], [60.2, 39.0], [60.3, 39.0], [60.4, 39.0], [60.5, 39.0], [60.6, 39.0], [60.7, 39.0], [60.8, 39.0], [60.9, 40.0], [61.0, 40.0], [61.1, 40.0], [61.2, 40.0], [61.3, 40.0], [61.4, 40.0], [61.5, 40.0], [61.6, 40.0], [61.7, 40.0], [61.8, 40.0], [61.9, 40.0], [62.0, 40.0], [62.1, 40.0], [62.2, 40.0], [62.3, 40.0], [62.4, 40.0], [62.5, 40.0], [62.6, 40.0], [62.7, 41.0], [62.8, 41.0], [62.9, 41.0], [63.0, 41.0], [63.1, 41.0], [63.2, 41.0], [63.3, 41.0], [63.4, 41.0], [63.5, 41.0], [63.6, 41.0], [63.7, 41.0], [63.8, 41.0], [63.9, 41.0], [64.0, 41.0], [64.1, 41.0], [64.2, 42.0], [64.3, 42.0], [64.4, 42.0], [64.5, 42.0], [64.6, 42.0], [64.7, 42.0], [64.8, 42.0], [64.9, 42.0], [65.0, 42.0], [65.1, 43.0], [65.2, 43.0], [65.3, 43.0], [65.4, 43.0], [65.5, 43.0], [65.6, 43.0], [65.7, 43.0], [65.8, 43.0], [65.9, 43.0], [66.0, 43.0], [66.1, 43.0], [66.2, 43.0], [66.3, 43.0], [66.4, 43.0], [66.5, 43.0], [66.6, 44.0], [66.7, 44.0], [66.8, 44.0], [66.9, 44.0], [67.0, 44.0], [67.1, 44.0], [67.2, 44.0], [67.3, 44.0], [67.4, 44.0], [67.5, 45.0], [67.6, 45.0], [67.7, 45.0], [67.8, 45.0], [67.9, 45.0], [68.0, 45.0], [68.1, 46.0], [68.2, 46.0], [68.3, 46.0], [68.4, 46.0], [68.5, 46.0], [68.6, 46.0], [68.7, 46.0], [68.8, 46.0], [68.9, 47.0], [69.0, 47.0], [69.1, 47.0], [69.2, 47.0], [69.3, 47.0], [69.4, 48.0], [69.5, 48.0], [69.6, 48.0], [69.7, 48.0], [69.8, 48.0], [69.9, 48.0], [70.0, 49.0], [70.1, 49.0], [70.2, 49.0], [70.3, 49.0], [70.4, 49.0], [70.5, 50.0], [70.6, 50.0], [70.7, 51.0], [70.8, 51.0], [70.9, 51.0], [71.0, 51.0], [71.1, 51.0], [71.2, 52.0], [71.3, 52.0], [71.4, 53.0], [71.5, 53.0], [71.6, 53.0], [71.7, 54.0], [71.8, 54.0], [71.9, 54.0], [72.0, 54.0], [72.1, 54.0], [72.2, 55.0], [72.3, 55.0], [72.4, 55.0], [72.5, 56.0], [72.6, 56.0], [72.7, 57.0], [72.8, 57.0], [72.9, 57.0], [73.0, 57.0], [73.1, 57.0], [73.2, 59.0], [73.3, 59.0], [73.4, 59.0], [73.5, 59.0], [73.6, 59.0], [73.7, 60.0], [73.8, 60.0], [73.9, 62.0], [74.0, 62.0], [74.1, 62.0], [74.2, 62.0], [74.3, 62.0], [74.4, 63.0], [74.5, 63.0], [74.6, 64.0], [74.7, 64.0], [74.8, 65.0], [74.9, 65.0], [75.0, 67.0], [75.1, 67.0], [75.2, 68.0], [75.3, 68.0], [75.4, 69.0], [75.5, 69.0], [75.6, 70.0], [75.7, 71.0], [75.8, 72.0], [75.9, 72.0], [76.0, 72.0], [76.1, 72.0], [76.2, 73.0], [76.3, 74.0], [76.4, 75.0], [76.5, 75.0], [76.6, 76.0], [76.7, 76.0], [76.8, 76.0], [76.9, 82.0], [77.0, 83.0], [77.1, 84.0], [77.2, 84.0], [77.3, 85.0], [77.4, 86.0], [77.5, 88.0], [77.6, 88.0], [77.7, 89.0], [77.8, 90.0], [77.9, 90.0], [78.0, 90.0], [78.1, 90.0], [78.2, 91.0], [78.3, 93.0], [78.4, 94.0], [78.5, 98.0], [78.6, 100.0], [78.7, 102.0], [78.8, 103.0], [78.9, 104.0], [79.0, 105.0], [79.1, 106.0], [79.2, 108.0], [79.3, 109.0], [79.4, 109.0], [79.5, 111.0], [79.6, 112.0], [79.7, 114.0], [79.8, 115.0], [79.9, 116.0], [80.0, 118.0], [80.1, 119.0], [80.2, 119.0], [80.3, 121.0], [80.4, 122.0], [80.5, 129.0], [80.6, 129.0], [80.7, 129.0], [80.8, 130.0], [80.9, 130.0], [81.0, 131.0], [81.1, 133.0], [81.2, 133.0], [81.3, 134.0], [81.4, 135.0], [81.5, 136.0], [81.6, 136.0], [81.7, 137.0], [81.8, 138.0], [81.9, 139.0], [82.0, 139.0], [82.1, 143.0], [82.2, 143.0], [82.3, 143.0], [82.4, 145.0], [82.5, 148.0], [82.6, 151.0], [82.7, 154.0], [82.8, 155.0], [82.9, 156.0], [83.0, 157.0], [83.1, 157.0], [83.2, 159.0], [83.3, 159.0], [83.4, 160.0], [83.5, 161.0], [83.6, 161.0], [83.7, 163.0], [83.8, 165.0], [83.9, 166.0], [84.0, 167.0], [84.1, 168.0], [84.2, 169.0], [84.3, 169.0], [84.4, 169.0], [84.5, 172.0], [84.6, 174.0], [84.7, 176.0], [84.8, 176.0], [84.9, 177.0], [85.0, 178.0], [85.1, 178.0], [85.2, 178.0], [85.3, 180.0], [85.4, 180.0], [85.5, 180.0], [85.6, 182.0], [85.7, 183.0], [85.8, 183.0], [85.9, 186.0], [86.0, 188.0], [86.1, 189.0], [86.2, 190.0], [86.3, 192.0], [86.4, 193.0], [86.5, 194.0], [86.6, 196.0], [86.7, 196.0], [86.8, 197.0], [86.9, 197.0], [87.0, 198.0], [87.1, 199.0], [87.2, 199.0], [87.3, 200.0], [87.4, 201.0], [87.5, 203.0], [87.6, 204.0], [87.7, 205.0], [87.8, 206.0], [87.9, 207.0], [88.0, 207.0], [88.1, 208.0], [88.2, 208.0], [88.3, 212.0], [88.4, 213.0], [88.5, 213.0], [88.6, 215.0], [88.7, 220.0], [88.8, 220.0], [88.9, 221.0], [89.0, 222.0], [89.1, 222.0], [89.2, 222.0], [89.3, 222.0], [89.4, 223.0], [89.5, 223.0], [89.6, 223.0], [89.7, 224.0], [89.8, 225.0], [89.9, 225.0], [90.0, 225.0], [90.1, 226.0], [90.2, 226.0], [90.3, 228.0], [90.4, 229.0], [90.5, 231.0], [90.6, 232.0], [90.7, 232.0], [90.8, 232.0], [90.9, 233.0], [91.0, 233.0], [91.1, 234.0], [91.2, 234.0], [91.3, 235.0], [91.4, 235.0], [91.5, 237.0], [91.6, 237.0], [91.7, 237.0], [91.8, 238.0], [91.9, 239.0], [92.0, 240.0], [92.1, 241.0], [92.2, 241.0], [92.3, 241.0], [92.4, 242.0], [92.5, 242.0], [92.6, 244.0], [92.7, 245.0], [92.8, 245.0], [92.9, 245.0], [93.0, 245.0], [93.1, 247.0], [93.2, 249.0], [93.3, 250.0], [93.4, 250.0], [93.5, 251.0], [93.6, 251.0], [93.7, 252.0], [93.8, 252.0], [93.9, 252.0], [94.0, 253.0], [94.1, 254.0], [94.2, 254.0], [94.3, 254.0], [94.4, 254.0], [94.5, 255.0], [94.6, 255.0], [94.7, 255.0], [94.8, 256.0], [94.9, 257.0], [95.0, 259.0], [95.1, 260.0], [95.2, 261.0], [95.3, 261.0], [95.4, 262.0], [95.5, 262.0], [95.6, 262.0], [95.7, 263.0], [95.8, 263.0], [95.9, 263.0], [96.0, 264.0], [96.1, 265.0], [96.2, 265.0], [96.3, 267.0], [96.4, 267.0], [96.5, 269.0], [96.6, 270.0], [96.7, 271.0], [96.8, 271.0], [96.9, 271.0], [97.0, 273.0], [97.1, 273.0], [97.2, 273.0], [97.3, 274.0], [97.4, 274.0], [97.5, 275.0], [97.6, 275.0], [97.7, 276.0], [97.8, 276.0], [97.9, 277.0], [98.0, 277.0], [98.1, 277.0], [98.2, 278.0], [98.3, 281.0], [98.4, 281.0], [98.5, 282.0], [98.6, 283.0], [98.7, 283.0], [98.8, 286.0], [98.9, 289.0], [99.0, 290.0], [99.1, 293.0], [99.2, 293.0], [99.3, 295.0], [99.4, 297.0], [99.5, 299.0], [99.6, 300.0], [99.7, 306.0], [99.8, 309.0], [99.9, 323.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 4.0, "minX": 0.0, "maxY": 786.0, "series": [{"data": [[0.0, 786.0], [300.0, 4.0], [100.0, 87.0], [200.0, 123.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 300.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 1000.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 1000.0, "series": [{"data": [[0.0, 1000.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 4.9E-324, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 3.2631578947368416, "minX": 1.792725364E12, "maxY": 24.462962962962962, "series": [{"data": [[1.792725372E12, 3.8300000000000005], [1.792725371E12, 3.854368932038836], [1.792725373E12, 3.606060606060605], [1.792725364E12, 24.32758620689655], [1.792725374E12, 3.2631578947368416], [1.792725365E12, 24.462962962962962], [1.792725366E12, 8.365217391304348], [1.792725368E12, 3.90909090909091], [1.792725367E12, 3.8613861386138613], [1.792725369E12, 5.739583333333333], [1.79272537E12, 4.470588235294117]], "isOverall": false, "label": "Thread Group", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.792725374E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 22.0, "minX": 1.0, "maxY": 295.0, "series": [{"data": [[2.0, 25.0], [3.0, 26.871428571428574], [4.0, 34.99722222222219], [5.0, 41.48148148148147], [6.0, 56.086956521739125], [7.0, 65.06666666666668], [8.0, 76.92857142857142], [9.0, 79.33333333333334], [10.0, 93.6], [11.0, 106.5], [12.0, 115.2], [13.0, 120.0], [14.0, 127.16666666666667], [15.0, 153.33333333333334], [16.0, 154.6], [1.0, 22.0], [17.0, 153.8], [18.0, 180.75], [19.0, 180.25], [20.0, 197.36363636363637], [21.0, 204.07142857142858], [22.0, 216.45454545454547], [23.0, 220.42857142857144], [24.0, 232.05555555555554], [25.0, 227.77272727272728], [26.0, 245.35], [27.0, 254.61538461538458], [28.0, 265.6875], [29.0, 280.00000000000006], [30.0, 280.8], [31.0, 295.0]], "isOverall": false, "label": "HTTP Request", "isController": false}, {"data": [[7.998000000000007, 73.78500000000003]], "isOverall": false, "label": "HTTP Request-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 31.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 7175.0, "minX": 1.792725364E12, "maxY": 51930.0, "series": [{"data": [[1.792725372E12, 45193.0], [1.792725371E12, 46573.0], [1.792725373E12, 44700.0], [1.792725364E12, 26191.0], [1.792725374E12, 8562.0], [1.792725365E12, 48797.0], [1.792725366E12, 51930.0], [1.792725368E12, 44723.0], [1.792725367E12, 45605.0], [1.792725369E12, 43369.0], [1.79272537E12, 46109.0]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.792725372E12, 37893.0], [1.792725371E12, 39054.0], [1.792725373E12, 37473.0], [1.792725364E12, 21957.0], [1.792725374E12, 7175.0], [1.792725365E12, 40913.0], [1.792725366E12, 43535.0], [1.792725368E12, 37496.0], [1.792725367E12, 38232.0], [1.792725369E12, 36361.0], [1.79272537E12, 38663.0]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.792725374E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 29.631578947368418, "minX": 1.792725364E12, "maxY": 237.46296296296296, "series": [{"data": [[1.792725372E12, 33.42], [1.792725371E12, 33.650485436893206], [1.792725373E12, 30.15151515151515], [1.792725364E12, 224.3965517241379], [1.792725374E12, 29.631578947368418], [1.792725365E12, 237.46296296296296], [1.792725366E12, 78.1217391304348], [1.792725368E12, 33.81818181818181], [1.792725367E12, 33.762376237623776], [1.792725369E12, 52.06249999999999], [1.79272537E12, 39.49019607843137]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.792725374E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 29.57894736842105, "minX": 1.792725364E12, "maxY": 237.46296296296296, "series": [{"data": [[1.792725372E12, 33.42], [1.792725371E12, 33.64077669902913], [1.792725373E12, 30.15151515151515], [1.792725364E12, 224.0862068965517], [1.792725374E12, 29.57894736842105], [1.792725365E12, 237.46296296296296], [1.792725366E12, 78.10434782608694], [1.792725368E12, 33.80808080808082], [1.792725367E12, 33.752475247524735], [1.792725369E12, 52.06249999999999], [1.79272537E12, 39.49019607843137]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.792725374E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.23232323232323232, "minX": 1.792725364E12, "maxY": 6.517241379310346, "series": [{"data": [[1.792725372E12, 0.3700000000000001], [1.792725371E12, 0.3786407766990291], [1.792725373E12, 0.23232323232323232], [1.792725364E12, 6.517241379310346], [1.792725374E12, 0.26315789473684215], [1.792725365E12, 0.4444444444444442], [1.792725366E12, 0.36521739130434777], [1.792725368E12, 0.4141414141414142], [1.792725367E12, 0.4455445544554455], [1.792725369E12, 0.3229166666666668], [1.79272537E12, 0.38235294117647056]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.792725374E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 19.0, "minX": 1.792725364E12, "maxY": 323.0, "series": [{"data": [[1.792725372E12, 65.0], [1.792725371E12, 72.0], [1.792725373E12, 52.0], [1.792725364E12, 323.0], [1.792725374E12, 51.0], [1.792725365E12, 309.0], [1.792725366E12, 186.0], [1.792725368E12, 59.0], [1.792725367E12, 57.0], [1.792725369E12, 157.0], [1.79272537E12, 76.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.792725372E12, 22.0], [1.792725371E12, 22.0], [1.792725373E12, 22.0], [1.792725364E12, 138.0], [1.792725374E12, 22.0], [1.792725365E12, 151.0], [1.792725366E12, 24.0], [1.792725368E12, 21.0], [1.792725367E12, 22.0], [1.792725369E12, 23.0], [1.79272537E12, 19.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.792725372E12, 40.900000000000006], [1.792725371E12, 44.60000000000001], [1.792725373E12, 37.0], [1.792725364E12, 276.1], [1.792725374E12, 41.0], [1.792725365E12, 282.1], [1.792725366E12, 145.00000000000003], [1.792725368E12, 43.0], [1.792725367E12, 40.8], [1.792725369E12, 99.79999999999998], [1.79272537E12, 56.7]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.792725372E12, 64.85999999999993], [1.792725371E12, 71.91999999999999], [1.792725373E12, 52.0], [1.792725364E12, 323.0], [1.792725374E12, 51.0], [1.792725365E12, 308.18999999999994], [1.792725366E12, 185.04000000000002], [1.792725368E12, 59.0], [1.792725367E12, 56.820000000000036], [1.792725369E12, 157.0], [1.79272537E12, 75.88]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.792725372E12, 33.5], [1.792725371E12, 33.0], [1.792725373E12, 30.0], [1.792725364E12, 226.0], [1.792725374E12, 27.0], [1.792725365E12, 242.0], [1.792725366E12, 67.0], [1.792725368E12, 33.0], [1.792725367E12, 34.0], [1.792725369E12, 39.5], [1.79272537E12, 38.0]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.792725372E12, 43.89999999999998], [1.792725371E12, 56.99999999999997], [1.792725373E12, 40.0], [1.792725364E12, 295.54999999999995], [1.792725374E12, 51.0], [1.792725365E12, 291.65], [1.792725366E12, 163.39999999999998], [1.792725368E12, 47.0], [1.792725367E12, 45.699999999999974], [1.792725369E12, 122.19999999999993], [1.79272537E12, 62.0]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.792725374E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 27.0, "minX": 19.0, "maxY": 242.0, "series": [{"data": [[19.0, 27.0], [99.0, 32.0], [96.0, 39.5], [101.0, 34.0], [102.0, 38.0], [103.0, 33.0], [100.0, 33.5], [108.0, 242.0], [115.0, 67.0], [58.0, 226.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 115.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 27.0, "minX": 19.0, "maxY": 242.0, "series": [{"data": [[19.0, 27.0], [99.0, 32.0], [96.0, 39.5], [101.0, 34.0], [102.0, 38.0], [103.0, 33.0], [100.0, 33.5], [108.0, 242.0], [115.0, 67.0], [58.0, 226.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 115.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 16.0, "minX": 1.792725364E12, "maxY": 100.0, "series": [{"data": [[1.792725372E12, 100.0], [1.792725371E12, 100.0], [1.792725373E12, 100.0], [1.792725364E12, 84.0], [1.792725374E12, 16.0], [1.792725365E12, 100.0], [1.792725366E12, 100.0], [1.792725368E12, 100.0], [1.792725367E12, 100.0], [1.792725369E12, 100.0], [1.79272537E12, 100.0]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.792725374E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 19.0, "minX": 1.792725364E12, "maxY": 115.0, "series": [{"data": [[1.792725372E12, 100.0], [1.792725371E12, 103.0], [1.792725373E12, 99.0], [1.792725364E12, 58.0], [1.792725374E12, 19.0], [1.792725365E12, 108.0], [1.792725366E12, 115.0], [1.792725368E12, 99.0], [1.792725367E12, 101.0], [1.792725369E12, 96.0], [1.79272537E12, 102.0]], "isOverall": false, "label": "201", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.792725374E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 19.0, "minX": 1.792725364E12, "maxY": 115.0, "series": [{"data": [[1.792725372E12, 100.0], [1.792725371E12, 103.0], [1.792725373E12, 99.0], [1.792725364E12, 58.0], [1.792725374E12, 19.0], [1.792725365E12, 108.0], [1.792725366E12, 115.0], [1.792725368E12, 99.0], [1.792725367E12, 101.0], [1.792725369E12, 96.0], [1.79272537E12, 102.0]], "isOverall": false, "label": "HTTP Request-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.792725374E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 19.0, "minX": 1.792725364E12, "maxY": 115.0, "series": [{"data": [[1.792725372E12, 100.0], [1.792725371E12, 103.0], [1.792725373E12, 99.0], [1.792725364E12, 58.0], [1.792725374E12, 19.0], [1.792725365E12, 108.0], [1.792725366E12, 115.0], [1.792725368E12, 99.0], [1.792725367E12, 101.0], [1.792725369E12, 96.0], [1.79272537E12, 102.0]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.792725374E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

